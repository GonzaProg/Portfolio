Unit Respuestas_Menu;

{$codepage UTF8}

INTERFACE

USES
  Crt, Archivo;

procedure cargando();
procedure iniciar_asistente (var arch:T_archivo);
procedure como ();
procedure listar_preguntas (var arch:T_archivo);
procedure agregar__preguntas_admin (var arch:T_archivo; var arch_pass:T_archivo_pass);

IMPLEMENTATION

procedure cargando();
var
 i:integer;
begin
     clrscr;
     textcolor(white);
     gotoxy(13,18);
     writeln('Cargando');
     gotoxy(14,19);
     for i:= 1 to 3 do
     begin
          textcolor(red);
            write('*');
          delay(100);
            write('***');
          delay(150);
            write('****');
          delay(200);
            write('*****');
          delay(250);
            write('*******');
          delay(300);
            write('**********');
     end;
     textcolor(white);
end;

//---------------------------------------------------------------------------------------------------------

procedure fallo_resp (var resp:string);
var
  num:byte;
begin
     num := random(6);
     case num of
     0: resp := 'Lo siento';
     1: resp := 'Perdón';
     2: resp := 'Rayos';
     3: resp := 'I´m sorry';
     4: resp := 'Caramba';
     5: resp := 'Carambis';
     end;
end;

procedure iniciar_asistente (var arch:T_archivo);
var
bot:string[42];
pregunta,nombre:string[50];
x:T_dato2;
enc,aux:boolean;
pos:cardinal;
resp:string;
begin
     clrscr;
     textcolor(green);
     bot := 'ASISTENTE VIRTUAL DE LICENCIA DE CONDUCIR';
     write('-',bot,': ');
     writeln('Hola. ¿Como es su nombre?');
     writeln();
     textcolor(cyan);
     write('-');
     readln(nombre);
     writeln();
     textcolor(green);
     write('-',bot,': ');
     writeln('Muy bien ',nombre,', comencemos:');
     writeln('¿Qué información sobre la licencia de conducir nacional desea obtener?  Presione 0 para salir');
     writeln();
     textcolor(cyan);
     write('-');
     readln(pregunta);
     aux := false;
     while pregunta <> '0' do
     begin
           clrscr;
           if aux = true then
               begin
               textcolor(green);
               gotoxy(8,6);
               writeln('¿Qué más desea saber sobre la licencia de conducir nacional?  Presione 0 para salir');
               writeln();
               textcolor(cyan);
               write('-');
               readln(pregunta);
               end;
           aux := true;
           enc := false;
           abrirbot(arch);
           pos := 0;
           while not EOF(arch) do
           begin
                seek(arch,pos);
                read(arch,x);
                if pregunta = x.pregunta then
                    begin
                    enc := true;
                    clrscr;
                    gotoxy(35,5);
                    write ('Pregunta: ',x.pregunta);
                    gotoxy(1,7);
                    write ('Respuesta: ',x.r1);
                    readkey;
                    end;
                pos := pos + 1;
           end;

           if (enc = false) and (pregunta <> '0') then
               begin
               clrscr;
               fallo_resp(resp);
               gotoxy(35,5);
               write (resp);;
               writeln(', no tengo respuesta a esa pregunta');
               readkey;
               end;
           close(arch);
     end;
     textcolor(white);
end;

//---------------------------------------------------------------------------------------------------------

procedure listar_preguntas (var arch:T_archivo);
var
i,j,aux:byte;
x:T_dato2;
begin
     clrscr;
     textcolor(red);
     gotoxy(50,5);
     writeln('Lista de preguntas');
     textcolor(white);
     i := 0;
     aux := 0;
     j := 0;
     textcolor(yellow);
     abrirbot(arch);
     while not EOF(arch) do
     begin
          aux := aux + 1;
          seek(arch,i);
          read(arch, x);
          if aux = 11 then
              begin
              readkey;
              clrscr;
              j := 0;
              aux := 1;
              end;
          gotoxy(1,7 + 2*j);
          writeln(x.pregunta);
          j := j + 1;
          i := i + 1;
     end;
     close(arch);
     readkey;
     clrscr;
     cargando();
end;

//---------------------------------------------------------------------------------------------------------

procedure como ();
begin
     clrscr;
     gotoxy(24,10);
     writeln(' Como funciona el asistente virtual ');
     gotoxy(24,12);
     textcolor(white);
     gotoxy(22,10);
     writeln('El asistente virtual, está diseñado para dar respuestas lógicas dependiendo');
     gotoxy(22,12);
     writeln('de la pregunta escrita por el usuario, conteniendo información útil');
     gotoxy(22,14);
     writeln('sobre sacar la licencia de conducir a nivel nacional.');
     gotoxy(22,18);
     textcolor(red);
     writeln('Toda la información contenida en este chatterbot fue seleccionada de una página oficial como:');
     gotoxy(22,19);
     writeln('  ARGENTINA.GOB.AR/SERVICIO/SACAR-LA-LICENCIA-NACIONAL-DE-CONDUCIR');
     textcolor(white);
     gotoxy(24,24);
     write('Presione una tecla para continuar...');
     readkey;
     clrscr;
     cargando();
end;

//---------------------------------------------------------------------------------------------------------

procedure agregar_preguntas(var arch:T_archivo);
var
resp:char;
x:T_dato2;
begin
     clrscr;
     textcolor(yellow);
     gotoxy(35,6);
     write ('Desea agregar preguntas? s/n');
     gotoxy(70,6);
     readln(resp);
     while resp <> 'n' do
     begin
          clrscr;
          gotoxy(35,6);
          write('Ingrese pregunta a agregar: ');
          readln(x.pregunta);
          gotoxy(27,8);
          write('Ingrese respuesta para la pregunta: ');
          readln (x.r1);
          abrirbot(arch);
          seek(arch,filesize(arch));
          write(arch,x);
          close(arch);
          clrscr;
          gotoxy(35,6);
          writeln('Desea agregar otra pregunta? s/n');
          readln(resp);
     end;
     textcolor(white);
end;

procedure agregar__preguntas_admin (var arch:T_archivo; var arch_pass:T_archivo_pass);
var
creado2:boolean;
pass,nopass:string[8];
begin
     abrir_pass(arch_pass,creado2);
     if creado2 = true then
         begin
         clrscr;
         textcolor(green);
         gotoxy(6,6);
         write('Ingrese nueva contraseña de administrador: ');
         readln(pass);
         write(arch_pass,pass);
         end
     else
         begin
         clrscr;
         read(arch_pass,pass);
         textcolor(red);
         gotoxy(6,6);
         write('Ingrese contraseña de administrador: ');
         readln(nopass);
         if nopass = pass then
             agregar_preguntas(arch)
         else
             begin
             gotoxy(13,7);
             writeln('Contraseña incorrecta');
             readkey;
             end;
         end;
     textcolor(white);
     close(arch_pass);
end;

END.

