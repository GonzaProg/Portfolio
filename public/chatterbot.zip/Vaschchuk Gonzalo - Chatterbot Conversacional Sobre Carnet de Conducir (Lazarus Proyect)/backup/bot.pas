Unit bot;

INTERFACE

USES
  Classes, SysUtils,crt;

CONST
n=40;
m=130;

TYPE
T_dato = record
    pregunta:string[m];
    respuesta0:string[M];
    respuesta1:string[M];
    respuesta2:string[M];
    respuesta3:string[M];
    respuesta4:string[M];
    respuesta5:string[M];
    respuesta6:string[M];
    cant:integer;
    nom:string[m];
  end;

T_punt = ^T_nodo;

T_nodo = record
info:T_dato;
sig:T_punt;
end;

T_lista = record
cab,act: T_punt;
tam: 1..n;
pos:byte;
end;

T_archivo = file of t_dato;

procedure crearlista(var l:t_lista);
procedure agregar (var l:t_lista; x:t_dato);
function tamanio (var l:t_lista): byte;
function lista_llena (var l:t_lista): boolean;
function lista_vacia (var l:t_lista): boolean;
procedure eliminarelemlista (var l:t_lista;buscado:string; var x:t_dato);
procedure siguiente(var l:t_lista);
procedure primero (var l:t_lista);
function fin (l:t_lista): boolean;
procedure recuperar (l:t_lista; var e:t_dato);
procedure eliminartodalista(l:t_lista);
procedure sigpregunta ( j,cant:integer; entrada:string; var x:t_dato );


IMPLEMENTATION

procedure mostrar_resp(var h:shortstring);
BEGIN
     writeln();
     textcolor (green);
     write ('-',h,': ');
END;

procedure crearlista(var l:t_lista);
begin
     l.tam:=0;
     l.cab:=nil;
end;

procedure agregar (var l:t_lista; x:t_dato);
var dir, ant, act: t_punt;
begin
     new (dir);
     dir^.info:= x;
     if (l.cab= nil) or (l.cab^.info.nom > x.nom) then
         begin
         dir^.sig:= l.cab;
         l. cab:=dir;
         end
     else
         begin
         ant:= l.cab;
         act:= l.cab^.sig;
         while (act <> nil) and (act^.info.nom < x.nom) do
         begin
              ant:= act;
              act:= act^.sig
         end;
         dir^.sig:= act;
         ant^.sig:= dir;
         end;
     inc(l.tam)
end;

procedure siguiente(var l:t_lista);
begin
     l.act:= l.act^.sig;
     inc(l.pos,1);
end;

procedure primero (var l:t_lista);
begin
     l.act:= l.cab;
     l.pos:=1;
end;

function fin (l:t_lista): boolean;
begin
     fin:=l.act = nil;
end;

function tamanio (var l:t_lista): byte;
begin
     tamanio:= l.tam;
end;

function lista_llena (var l:t_lista): boolean;
begin
     lista_llena:= getheapstatus.totalfree < sizeof(t_dato) ;
end;

function lista_vacia (var l:t_lista): boolean;
begin
     lista_vacia:= l.tam=0;
end;

procedure recuperar (l:t_lista; var e:t_dato);
begin
     e:= l.act^.info;
end;

procedure eliminarelemlista (var l:t_lista;buscado:string; var x:t_dato);
var act, ant: t_punt;
begin
     if (l.cab^.info.pregunta= buscado) then
         begin
         x:= l.cab^.info;
         act:=l.cab;
         l.cab:=l.cab^.sig;
         dispose (act);
         end
     else
         begin
         ant:=l.cab;
         act:= l.cab^.sig;
         while (act <> nil) and (act^.info.pregunta< x.pregunta) do
         begin
              ant:=act;
              act:= act^.sig;
         end;
         x:= act^.info;
         ant^.sig:= act^.sig;
         dispose (act);
         end;
     dec(l.tam);
end;

procedure eliminartodalista(l:t_lista);
begin
     while l.cab<>nil do
     begin
          l.act:=l.cab;
          l.cab:=l.cab^.sig;
          dispose(l.act);
     end;
     l.tam:=0;
end;

procedure sigpregunta ( j,cant:integer; entrada:string; var x:T_dato );
begin
     case j of
          1: x.respuesta0:= entrada;
          2: x.respuesta1:= entrada;
          3: x.respuesta2:= entrada;
          4: x.respuesta3:= entrada;
          5: x.respuesta4:= entrada;
          6: x.respuesta5:= entrada;
          7: x.respuesta6:= entrada;
     end;
     x.cant:= cant;
end;

END.
