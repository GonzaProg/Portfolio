unit Respuestas;

{$codepage UTF8}

interface
uses
  Crt, bot;
  var
    arch:t_archivo;
    E:t_dato;
    Chat:string;


Procedure Robot ();
procedure Hola (var E:t_dato);
procedure color ();

implementation

Procedure Robot ();
begin
   Chat:='ASISTENTE VIRTUAL DE COVID';
end;
procedure color ();
begin
   textcolor(green);
end;

procedure Hola (var E:t_dato); //HOLA
var aux:byte;
 begin
   randomize;
   aux:=random(4);
   writeln();
   color ();
   write ('-',Chat,': ');
    case aux of
     0: writeln(E.respuesta0);
     1: writeln(E.respuesta1);
     2: writeln(E.respuesta2);
     3: writeln(E.respuesta3);
 end;
 end;

end.

