Unit Llenado;

{$codepage UTF8}

INTERFACE

USES
 Archivo, crt;

procedure agregar_preguntas(var arch:T_archivo);

IMPLEMENTATION

procedure agregar_preguntas(var arch:T_archivo);
var
resp:char;
x:T_dato2;
begin
     clrscr;
     gotoxy(35,6);
     write ('Desea agregar preguntas? s/n');
     gotoxy(70,6);
     readln(resp);
     while resp <> 'n' do
     begin
          clrscr;
          gotoxy(35,6);
          writeln('Ingrese pregunta a agregar: ');
          readln(x.pregunta);
          gotoxy(37,8);
          writeln('Ingrese respuesta para la pregunta: ');
          readln (x.r1);
          abrirbot(arch);
          seek(arch,filesize(arch));
          write(arch,x);
          close(arch);
          writeln('Desea agregar otra pregunta? s/n');
          readln(resp);
     end;
end;

END.
