Unit Menu;

INTERFACE

{$codepage UTF8}

USES
  crt, Preguntas, Archivo, Respuestas_Menu;

procedure menu1 (var arch:T_archivo; var arch_pass:T_archivo_pass);
procedure inicia ();

IMPLEMENTATION

procedure inicia ();
begin
     textcolor(white);
     gotoxy(24,12);
     writeln(' Presione "Enter" para ingresar al menú de opciones sobre: ');
     gotoxy(24,14);
     writeln('         "Sacar la Licencia Nacional de Conducir"        ');
     textcolor(white);
     readkey;
     clrscr;
end;

procedure confirmacion_datos_menu (var opcion:byte);
begin
     while opcion > 4 do
     begin
          gotoxy(36,22);
          write('Valor incorrecto');
          gotoxy(36,23);
          write('Pruebe de nuevo: ');
          readln (opcion);
     end;
end;

procedure menu1 (var arch:T_archivo; var arch_pass:T_archivo_pass);
var
 opcion:byte;
begin
     preguntas_respuestas(arch);
     REPEAT
     begin
          clrscr;
          textcolor(yellow);
          gotoxy(26,6);
            writeln('  Menú de opciones sobre sacar la licencia nacional de conducir      ');
          textcolor(white);
          gotoxy(36,10);
            writeln('*   1- Iniciar asistente virtual            ');
          gotoxy(36,12);
            writeln('*   2- Mostrar lista de preguntas           ');
          gotoxy(36,14);
            writeln('*   3- Cómo funciona el asistente virtual   ');
          gotoxy(36,16);
            write('*   4- Agregar Pregunta ');textcolor(red); write('  (Solo Administrador)');
          textcolor(white);
          gotoxy(36,18);
            writeln('*   0- Salir             ');
          gotoxy(36,20);
          write('Selecione una opción : ');
          readln(opcion);
          confirmacion_datos_menu(opcion);
          cargando();
          clrscr;
     end;

     case opcion of
     1: iniciar_asistente(arch);

     2: listar_preguntas(arch);

     3: como();

     4: agregar__preguntas_admin(arch,arch_pass);
     end;

     UNTIL (opcion=0);
end;

END.
