Unit Menu;

INTERFACE

{$codepage UTF8}

USES
  crt, Preguntas, Archivo, Llenado;

procedure menu (var arch:T_archivo; var arch_pass:T_archivo_pass);
procedure inicia ();
procedure cargando();

IMPLEMENTATION

procedure inicia ();
begin
     textcolor(white);
     gotoxy(24,12);
     writeln(' Presione "Enter" para ingresar al menú de opciones sobre: ');
     gotoxy(24,14);
     writeln('         "Sacar la Licencia Nacional de Conducir"        ');
     textcolor(white);
     readkey;
     clrscr;
end;

procedure confirmacion_datos_menu (var opcion);
begin
     while opcion > 4 do
     begin
          gotoxy(36,22);
          write('Valor incorrecto');
          gotoxy(36,23);
          write('Pruebe de nuevo: ');
          readln (opcion);
     end;
end;

procedure menu (var arch:T_archivo; var arch_pass:T_archivo_pass);
var
 i:cardinal;
 opcion:byte;
 pass,nopass:string[8];
 x:t_dato2;
 creado2:boolean;
begin
     preguntas_respuestas(arch);
     REPEAT
     begin
          clrscr;
          textcolor(yellow);
          gotoxy(26,6);
            writeln('  Menú de opciones sobre sacar la licencia nacional de conducir      ');
          textcolor(white);
          gotoxy(36,10);
            writeln('*   1- Iniciar asistente virtual            ');
          gotoxy(36,12);
            writeln('*   2- Mostrar lista de preguntas           ');
          gotoxy(36,14);
            writeln('*   3- Cómo funciona el asistente virtual   ');
          gotoxy(36,16);
            write('*   4- Agregar Pregunta ');textcolor(red); write('  (Solo Administrador)');
          textcolor(white);
          gotoxy(36,18);
            writeln('*   0- Salir             ');
          gotoxy(36,20);
          write('Selecione una opción : ');
          readln(opcion);
          confirmacion_datos_menu(opcion);
          cargando();
          clrscr;
     end;//menu

     case opcion of
     1:begin //guardar
             clrscr;
             pregunta(arch);
       end;

     2:begin
              clrscr;
              gotoxy(24,10);
              writeln('  Lista de preguntas ');
              textcolor(white);
              i := 0;
              abrirbot(arch);
              while not EOF(arch) do
              begin
                   seek(arch,i);
                   read(arch, x);
                   writeln(x.pregunta);
                   writeln;
                   i := i + 1;
              end;
              close(arch);
              readkey;
              clrscr;
              cargando();
       end;

     3:begin
            clrscr;
            gotoxy(24,10);
            writeln(' Como funciona el asistente virtual ');
            gotoxy(24,12);
            textcolor(white);
            como ();
            clrscr;
            cargando();
       end;

     4:begin
            abrir_pass(arch_pass,creado2);
            if creado2 = true then
                begin
                clrscr;
                TEXTCOLOR(WHITE);
                gotoxy(6,6);
                write('Ingrese nueva contraseña de administrador: ');
                readln(pass);
                write(arch_pass,pass);
                close(arch_pass);
                end
            else
                begin
                clrscr;
                read(arch_pass,pass);
                TEXTCOLOR(WHITE);
                gotoxy(6,6);
                write('Ingrese contraseña de administrador: ');
                readln(nopass);
                if nopass = pass then
                    begin
                    agregar_preguntas(arch);
                    end
                else
                    begin
                    gotoxy(13,7);
                    writeln('Contraseña incorrecta');
                    readkey;
                    end;
                close(arch_pass);
                end;

       end;

     0: clrscr;

     end;
     UNTIL (opcion=0);
end;

procedure  cargando();
var
 i:integer;
begin
     clrscr;
     textcolor(white);
     gotoxy(13,18);
     writeln('Cargando');
     gotoxy(14,19);
     for i:= 1 to 3 do
     begin
          textcolor(red);
            write('*');
          delay(100);
            write('***');
          delay(150);
            write('****');
          delay(200);
            write('*****');
          delay(250);
            write('*******');
          delay(300);
            write('**********');
     end;
end;

END.
