Unit Archivo;

INTERFACE

USES
   crt;

CONST
   ruta = 'D:\ARCHIVOS\chatterbot.dat';
   ruta2 = 'D:\ARCHIVOS\pass.dat';
   ruta3 = 'D:\ARCHIVOS\arch_agregar.dat';

TYPE
  T_dato2 = record
    pregunta: string[70];
    r1:string[255];
  end;

  T_archivo = file of T_dato2;

  T_archivo_pass = file of string[8];


procedure abrirbot(var arch:T_archivo);
procedure abrir(var arch:T_archivo; var creado:boolean);
procedure abrir_pass(var arch_pass:T_archivo_pass; var creado2:boolean);

IMPLEMENTATION

procedure abrirbot(var arch:T_archivo);
begin
     assign(arch,ruta);
     reset (arch);
end;

procedure abrir(var arch:T_archivo; var creado:boolean);
begin
     creado := false;
     assign(arch,ruta);
     {$i-}
     reset (arch);
     {$i+}
     if IOResult <> 0 then
         begin
         rewrite(arch);
         creado := true;
         end;
end;

procedure abrir_pass(var arch_pass:T_archivo_pass; var creado2:boolean);
begin
     creado2 := false;
     assign(arch_pass,ruta2);
     {$i-}
     reset (arch_pass);
     {$i+}
     if IOResult <> 0 then
         begin
         rewrite(arch_pass);
         creado2 := true;
         end;
end;

END.
