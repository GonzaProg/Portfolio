Unit Preguntas;

{$codepage UTF8}

INTERFACE

USES
  Crt, Archivo;

CONST
  k = 33;


procedure preguntas_respuestas (var arch:T_archivo);

IMPLEMENTATION

procedure inicializar_preguntas (var preg:T_dato2);
begin
     preg.pregunta := '';
     preg.r1 := '';
end;

procedure preguntas_respuestas (var arch:T_archivo);
var
  creado:boolean;
  i:0..k;
  preg:T_dato2;
begin
     abrir(arch,creado);
     if creado = true then
         begin
         for i := 0 to k do
         begin
              case i of
              0: begin
                 inicializar_preguntas(preg);
                 preg.pregunta := 'Que edad debo tener para conducir un vehiculo?';
                 preg.r1 := 'Para conducir vehículos por la vía pública se deben tener cumplidas las siguientes edades, según el caso: Veintiún (21) años para las clases C, D y E. Diecisiete (17) años para las restantes clases. Dieciséis (16) años para ciclomotores.';
                 end;
              1: begin
                 inicializar_preguntas(preg);
                 preg.pregunta := 'Que se puede conducir con 16 anios?';
                 preg.r1 := 'A partir de esta edad se pueden conducir coches de hasta 3.500 kg, sin límite de potencia y hasta 120 km/h.';
                 end;
              2: begin
                 inicializar_preguntas(preg);
                 preg.pregunta := 'Quien deberia sacar la licencia?';
                 preg.r1 := 'Toda persona que quiera conducir un vehiculo o moto en la argentina';
                 end;
              3: begin
                 inicializar_preguntas(preg);
                 preg.pregunta := 'Que necesito para sacar la licencia?';
                 preg.r1 := 'Debes tener 18 años o más para poder sacar la licencia de forma independiente';
                 end;
              4: begin
                 inicializar_preguntas(preg);
                 preg.pregunta := 'Que debo hacer si soy menor de 18 anios y quiero sacar la licencia?';
                 preg.r1 := 'Si eres menor de 18 años necesitas estar autorizado por tu representante legal';
                 end;
              5: begin
                 inicializar_preguntas(preg);
                 preg.pregunta := 'Que debo llevar al momento de sacar la licencia?';
                 preg.r1 := 'Debes presentarte con tu DNI original y una copia del mismo';
                 end;
              6: begin
                 inicializar_preguntas(preg);
                 preg.pregunta := 'Como hago para abonar el carnet?';
                 preg.r1 := 'Debes generar la boleta de pago para el CENAT desde la página de Seguridad Vial de la Provincia de Buenos Aires e imprimí la boleta de pago del certificado nacional de antecedentes de transito';
                 end;
              7: begin
                 inicializar_preguntas(preg);
                 preg.pregunta := 'Donde debo pedir turno para sacar mi licencia?';
                 preg.r1 := 'Saca turno en el municipio que corresponde a tu domicilio. Podes ver todos los municipios que emiten la licencia nacional en la pagina https://www.argentina.gob.ar/seguridadvial/municipios-licencia-nacional';
                 end;
              8: begin
                 inicializar_preguntas(preg);
                 preg.pregunta := 'Que debo aprobar para tener mi licencia?';
                 preg.r1 := 'Deberás aprobar un curso teórico y práctico, un examen psicofísico, teórico de conocimiento sobre ética ciudadana, conducción, señalamiento, legislación, teórico práctico de detección de fallas y un práctico de conducción.';
                 end;
              9: begin
                 inicializar_preguntas(preg);
                 preg.pregunta := 'Cual es el costo del trámite?';
                 preg.r1 := 'Consulta el valor en la jurisdicción provincial o municipal que corresponda a tu domicilio';
                 end;
              10: begin
                 inicializar_preguntas(preg);
                 preg.pregunta := 'Que es clase A1?';
                 preg.r1 := 'Ciclomotores y motocicletas';
                 end;
              11: begin
                 inicializar_preguntas(preg);
                 preg.pregunta := 'Que es clase A1.1?';
                 preg.r1 := 'Ciclomotores hasta cincuenta centímetros cúbicos (50 cc) de cilindrada o cuatro kilowatts(4 kw) de potencia máxima continua nominal si se trata de motorización eléctrica.';
                 end;
              12: begin
                 inicializar_preguntas(preg);
                 preg.pregunta := 'Que es clase A1.2?';
                 preg.r1 := 'Motocicletas hasta ciento cincuenta centímetros cúbicos (150 cc) de cilindrada u once kilowatts (11 kw) de potencia máxima continua nominal si se trata de motorización eléctrica. Incluye clase A 1.1';
                 end;
              13: begin
                 inicializar_preguntas(preg);
                 preg.pregunta := 'Que es clase A1.3?';
                 preg.r1 := 'Motocicletas de más de 150cc y hasta 300cc de cilindrada o de más de 11kw y hasta 20kw de potencia máx. si se trata de motorización eléctrica. Necesita una antigüedad de 2 años en la clase A1.2, excepto mayores de 21 años de edad. Incluye clase A1.2.';
                 end;
              14: begin
                 inicializar_preguntas(preg);
                 preg.pregunta := 'Que es clase A1.4?';
                 preg.r1 := 'Motocicletas de más de 300 cc o de más de 20 kw de potencia máx. si se trata de motorización eléctrica. Necesita una antigüedad de 2 años en la clase A1.3, excepto los mayores de 21 años que deben poseer 1 año en motocicletas de cualquier cilindrada';
                 end;
              15: begin
                 inicializar_preguntas(preg);
                 preg.pregunta := 'Que es clase A2?';
                 preg.r1 := 'Triciclos y cuatriciclos sin cabina de cualquier cilindrada o kilowatts de potencia máxima contínua.';
                 end;
              16: begin
                 inicializar_preguntas(preg);
                 preg.pregunta := 'Que es clase A2.1?';
                 preg.r1 := 'Triciclos y cuatriciclos sin cabina de hasta trescientos centímetros cúbicos (300 cc) o veinte kilowatts (20 kw) de potencia máxima continua nominal si se trata de motorización eléctrica con manillar o manubrio direccional.';
                 end;

              17: begin
                 inicializar_preguntas(preg);
                 preg.pregunta := 'Que es clase A2.2?';
                 preg.r1 := 'Triciclos y cuatriciclos sin cabina de más de 300 cc o 20 kw de potencia máxima continua nominal si se trata de motorización eléctrica con manillar o manubrio direccional. Necesita una antigüedad previa de dos años en la clase A2.1';
                 end;
              18: begin
                 inicializar_preguntas(preg);
                 preg.pregunta := 'Que es clase A3?';
                 preg.r1 := 'Triciclos y cuatriciclos cabinados de cualquier cilindrada o kilowatts de potencia máxima continua con volante direccional.';
                 end;
              19: begin
                 inicializar_preguntas(preg);
                 preg.pregunta := 'Que es clase B1?';
                 preg.r1 := 'Automóviles, utilitarios, camionetas, vans de uso privado y casas rodantes motorizadas hasta tres mil quinientos kilogramos (3500 kg) de peso total. Incluye clase A 3.';
                 end;
              20: begin
                 inicializar_preguntas(preg);
                 preg.pregunta := 'Que es clase B2?';
                 preg.r1 := 'Automóviles, camionetas, vans de uso privado y casas rodantes motorizadas hasta tres mil quinientos kilogramos (3500 kg) de peso con un acoplado de hasta 750 kg o casa rodante no motorizada. Requerirá un año de antigüedad en la clase B1.';
                 end;
              21: begin
                 inicializar_preguntas(preg);
                 preg.pregunta := 'Que es clase C1?';
                 preg.r1 := ' Camiones sin acoplado, ni semiacoplado, ni articulado y vehículos o casa rodante motorizada de más de tres mil quinientos kilogramos (3500 kg) de peso y hasta doce mil kilogramos (12.000 kg) de peso. Incluye clase B1.';
                 end;
              22: begin
                 inicializar_preguntas(preg);
                 preg.pregunta := 'Que es clase C2?';
                 preg.r1 := 'Camiones sin acoplado, ni semiacoplado, ni articulado y vehículos o casa rodante motorizada de más de doce mil kilogramos (12.000 kg) de peso y hasta veinticuatro mil kilogramos (24.000 kg). Incluye clase C 1.';
                 end;

              23: begin
                 inicializar_preguntas(preg);
                 preg.pregunta := 'Que es clase C3?';
                 preg.r1 := 'Camiones sin acoplado, ni semiacoplado, ni articulado y vehículos o casa rodante motorizada de más de veinticuatro mil kilogramos (24.000 kg) de peso. Incluye clase C 2.';
                 end;

              24: begin
                 inicializar_preguntas(preg);
                 preg.pregunta := 'Que es clase D1?';
                 preg.r1 := 'Automotores para servicios de transporte de pasajeros hasta ocho (8) plazas, excluido el conductor. Incluye clase B 1';
                 end;
              25: begin
                 inicializar_preguntas(preg);
                 preg.pregunta := 'Que es clase D2?';
                 preg.r1 := 'Automotores para servicios de transporte de pasajeros de más de ocho (8) plazas y hasta veinte (20) plazas, excluido el conductor.';
                 end;

              26: begin
                 inicializar_preguntas(preg);
                 preg.pregunta := 'Que es clase D3?';
                 preg.r1 := 'Automotores para servicios de transporte de pasajeros de más de veinte (20) plazas, excluido el conductor. Incluye clase D 2.';
                 end;

              27: begin
                 inicializar_preguntas(preg);
                 preg.pregunta := 'Que es clase D4?';
                 preg.r1 := 'Vehículos para servicios de urgencia, emergencia y similares. Esta subclase D.4 deberá encontrarse acompañada de la correspondiente subclase A, B, C, D o E según corresponda.';
                 end;
              28: begin
                 inicializar_preguntas(preg);
                 preg.pregunta := 'Que es clase E1?';
                 preg.r1 := 'Vehículos automotores de clase C o D, según el caso, con uno o más remolques o articulaciones. Incluye clase B2.';
                 end;
              29: begin
                 inicializar_preguntas(preg);
                 preg.pregunta := 'Que es clase E2?';
                 preg.r1 := 'Maquinaria especial no agricola';
                 end;
              30: begin
                 inicializar_preguntas(preg);
                 preg.pregunta := 'Que es clase F?';
                 preg.r1 := 'Vehículo automotor especialmente adaptado a la condición física de su titular. La licencia deberá consignar la descripción de la adaptación que corresponda.';
                 end;

              31: begin
                 inicializar_preguntas(preg);
                 preg.pregunta := 'Que es clase G1?';
                 preg.r1 := 'Tractores agrícolas.';
                 end;
              32: begin
                 inicializar_preguntas(preg);
                 preg.pregunta := 'Que es clase G2?';
                 preg.r1 := 'Maquinaria especial agrícola.';
                 end;
              33: begin
                 inicializar_preguntas(preg);
                 preg.pregunta := 'Que es clase G3?';
                 preg.r1 := 'Tren agrícola, deberá encontrarse acompañada de la subclase B1 o G1 según corresponda y se debe acreditar una antigüedad previa de un (1) año en la correspondiente subclase.';
                 end;
             end;
         seek(arch,i);
         write(arch,preg);
         end;
         end;
     close(arch);
end;

END.
