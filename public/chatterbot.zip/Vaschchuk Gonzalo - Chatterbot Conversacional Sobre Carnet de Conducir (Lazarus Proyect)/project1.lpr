Program project1;

USES
  Menu, Archivo;

var
  arch:T_archivo;
  arch_pass:T_archivo_pass;

begin
inicia();
menu1(arch,arch_pass);
END.

