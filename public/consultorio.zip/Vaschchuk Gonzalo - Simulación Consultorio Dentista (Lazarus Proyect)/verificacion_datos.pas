Unit Verificacion_datos;

INTERFACE

USES
  Crt;

procedure confirmacion_datos_menu (var opcion:byte);
procedure confirmacion_datos_ABMC_Personas (var opcion:byte);
procedure confirmacion_datos_ABMC_Atenciones (var opcion:byte);
procedure confirmacion_datos_estadisticas (var opcion:byte);
procedure confirmacion_alta_baja (var resp:char);
procedure confirmacion_cambios (var resp:char);
procedure confirmacion_datos_modificacion (var resp:byte);
procedure confirmacion_persona_cargada (var resp1:byte);
procedure confirmacion_datos (var resp:char);
procedure confirmacion_datos2 (var resp1:byte);
procedure confirmacion_tratamientos (var resp:char);

IMPLEMENTATION

procedure confirmacion_datos_menu (var opcion:byte);
begin
     while (opcion > 7) do
     begin
          gotoxy(35,15);
          write ('Valor incorrecto');
          gotoxy(35,16);
          write ('Pruebe de nuevo: ');
          readln(opcion);
     end;
end;

procedure confirmacion_datos_ABMC_Personas (var opcion:byte);
begin
     while (opcion > 4) do
     begin
          gotoxy(35,12);
          write ('Valor incorrecto');
          gotoxy(35,13);
          write ('Pruebe de nuevo: ');
          readln(opcion);
     end;
end;

procedure confirmacion_datos_ABMC_Atenciones (var opcion:byte);
begin
     while (opcion > 2) do
     begin
          gotoxy(35,10);
          writeln ('Valor incorrecto');
          gotoxy(35,11);
          write ('Pruebe de nuevo: ');
          readln(opcion);
     end;
end;

procedure confirmacion_datos_estadisticas (var opcion:byte);
begin
     while (opcion > 5) do
     begin
          gotoxy(35,13);
          writeln ('Valor incorrecto');
          gotoxy(35,14);
          write ('Pruebe de nuevo: ');
          readln(opcion);
     end;
end;

procedure confirmacion_alta_baja (var resp:char);
begin
     while (resp <> 's') and (resp <> 'S') and (resp <> 'n') and (resp <> 'N') do
     begin
          gotoxy(40,22);
          write ('Debe ingresar "s" o "n"');
          gotoxy(40,23);
          write ('Pruebe de nuevo: ');
          readln(resp);
     end;
end;

procedure confirmacion_cambios (var resp:char);
begin
     while (resp <> 's') and (resp <> 'S') and (resp <> 'n') and (resp <> 'N') do
     begin
          gotoxy(35,22);
          write ('Debe ingresar "s" o "n"');
          gotoxy(35,23);
          write ('Pruebe de nuevo: ');
          readln(resp);
     end;
end;

procedure confirmacion_datos_modificacion (var resp:byte);
begin
     while resp > 7 do
     begin
          gotoxy(34,16);
          writeln ('Valor incorrecto');
          gotoxy(34,17);
          write ('Pruebe de nuevo: ');
          readln(resp);
     end;
end;

procedure confirmacion_persona_cargada (var resp1:byte);
begin
     while (resp1 > 3) do
     begin
          gotoxy(35,27);
          writeln ('Valor incorrecto');
          gotoxy(35,28);
          write ('Pruebe de nuevo: ');
          readln(resp1);
     end;
end;

procedure confirmacion_datos (var resp:char);
begin
     while (resp <> 's') and (resp <> 'S') and (resp <> 'n') and (resp <> 'N') do
     begin
          gotoxy(35,7);
          write ('Debe ingresar "s" o "n"');
          gotoxy(35,8);
          write ('Pruebe de nuevo: ');
          readln(resp);
     end;
end;

procedure confirmacion_datos2 (var resp1:byte);
begin
     while resp1 > 2 do
     begin
          gotoxy(35,10);
          write ('Valor incorrecto');
          gotoxy(35,11);
          write ('Pruebe de nuevo: ');
          readln(resp1);
     end;
end;

procedure confirmacion_tratamientos (var resp:char);
begin
     while (resp <> 's') and (resp <> 'S') and (resp <> 'n') and (resp <> 'N') do
     begin
          gotoxy(35,16);
          write ('Debe ingresar "s" o "n"');
          gotoxy(35,17);
          write ('Pruebe de nuevo: ');
          readln(resp);
     end;
end;

END.

