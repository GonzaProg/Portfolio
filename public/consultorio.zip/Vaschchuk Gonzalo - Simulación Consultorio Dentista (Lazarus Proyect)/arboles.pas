Unit Arboles;

INTERFACE

USES
   CRT,Def_Archivo_Personas,Def_Archivo_Atenciones;

TYPE
T_dato_arbol = record
clave: string[50];
posicion: cardinal;
end;

T_punt = ^T_nodo;

T_nodo = record
info: T_dato_arbol;
sai,sad: T_punt;
end;

procedure crear_arbol (var raiz:T_punt);
procedure agregar (var raiz:T_punt; x:T_dato_arbol);
function arbol_vacio (raiz:T_punt): boolean;
function arbol_lleno (raiz:T_punt): boolean;

IMPLEMENTATION

procedure crear_arbol (var raiz:T_punt);
begin
     raiz:= nil;
end;

procedure agregar (var raiz:T_punt; x:T_dato_arbol);
begin
     if raiz = nil then
     begin
        new (raiz);
        raiz^.info:= x;
        raiz^.sai:= nil;
        raiz^.sad:= nil;
     end
     else
        if raiz^.info.clave > x.clave then
           agregar(raiz^.sai,x)
        else
           agregar(raiz^.sad,x);
end;

function arbol_vacio (raiz:T_punt):boolean;
begin
     arbol_vacio:= raiz = nil;
end;

function arbol_lleno (raiz:T_punt):boolean;
begin
     arbol_lleno:= getheapstatus.totalfree < sizeof (T_nodo);
end;

END.
