Unit Def_Archivo_Personas;

INTERFACE

USES
  Crt;

CONST
  ruta_personas = 'C:\ARCHIVOS\personas.dat';

TYPE
T_dato_personas = record
posicion:cardinal;
nombre_apellido: string[50];
direccion: string[20];
ciudad: string[50];
dni: string[10];
fecha_nacimiento: record
                        anio: string[4];
                        mes: string[2];
                        dia: string[2];
                  end;
telefono: string[20];
nombre_obra_social: string[30];
numero_afiliado_obra: string[15];
estado: boolean;
end;

T_archivo_personas = file of T_dato_personas;

procedure abrirpersonas (var arch_personas:T_archivo_personas);

IMPLEMENTATION

procedure abrirpersonas (var arch_personas:T_archivo_personas);
begin
  assign (arch_personas,ruta_personas);
     {$i-}
     reset (arch_personas);
     {$i+}
     if IOResult <> 0 then
         rewrite(arch_personas);
  end;

END.

