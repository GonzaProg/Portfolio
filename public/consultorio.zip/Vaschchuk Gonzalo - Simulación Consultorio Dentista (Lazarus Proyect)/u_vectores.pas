Unit U_vectores;

INTERFACE

{$codepage UTF8}

USES
crt;

CONST
m = 12;

TYPE
T_dato_vec = record
   cant_atenciones: word;
   mes:string[15];
end;

T_vector = array [1..m] of T_dato_vec;

procedure inicializar (var vec:T_vector);

IMPLEMENTATION

procedure inicializar (var vec:T_vector);
var
i: 1..m;
begin
     for i:= 1 to m do
     begin
          vec[i].cant_atenciones:= 0;
          vec[i].mes := '';
     end;
end;

END.
