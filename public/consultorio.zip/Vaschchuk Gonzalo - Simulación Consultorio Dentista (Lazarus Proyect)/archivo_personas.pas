Unit Archivo_Personas;

{$codepage UTF8}

INTERFACE

USES
  Crt,Usar_Arboles,Def_Archivo_Personas,Arboles,Def_Archivo_Atenciones,Archivo_Atenciones,Estadisticas,Cuadro_de_atenciones,Verificacion_datos;

procedure cargar_personas (var arch_personas:T_archivo_personas; var raiz,raiz1:T_punt);
procedure bajapersonas (var arch_personas:T_archivo_personas; var raiz,raiz1:T_punt);
procedure modificacionpersonas (var arch_personas:T_archivo_personas; var raiz,raiz1:T_punt);
procedure consultapersonas (var arch_personas:T_archivo_personas; var raiz,raiz1:T_punt);
procedure pasarpersonas(var raiz,raiz1:T_punt; var arch_personas:t_archivo_personas);
procedure consulta_datos_paciente (var arch_personas:T_archivo_personas; var arch_atenciones:T_archivo_atenciones; var raiz,raiz1:T_Punt);
procedure orden_obra_social (var arch_atenciones: T_archivo_atenciones; var arch_personas: T_archivo_personas; var raiz,raiz1:T_Punt);

IMPLEMENTATION

procedure pasarpersonas(var raiz,raiz1:T_punt; var arch_personas:t_archivo_personas);
var
   pos:cardinal;
   x:T_dato_personas;
   x2:T_dato_arbol;
begin
     abrirpersonas (arch_personas);
     pos := 0;
     while not EOF(arch_personas) do
     begin
          Seek (arch_personas,pos);
          read (arch_personas,x);
          x2.clave := x.dni;
          x2.posicion := x.posicion;
          agregar(raiz,x2);
          x2.clave := x.nombre_apellido;
          agregar(raiz1,x2);
          pos:= pos+1;
     end;
     Close (arch_personas);
end ;

procedure mostrar_datos_personas (x:T_dato_personas);
begin
     gotoxy(35,7);
     Writeln ('Nombre y apellido: ', x.nombre_apellido);
     gotoxy(35,8);
     Writeln ('Dirección: ', x.direccion);
     gotoxy(35,9);
     Writeln ('Ciudad: ', x.ciudad);
     gotoxy(35,10);
     Writeln ('DNI: ', x.dni);
     gotoxy(35,11);
     Writeln ('Fecha de nacimiento: ');
     gotoxy(35,12);
     Writeln ('Año: ', x.fecha_nacimiento.anio);
     gotoxy(35,13);
     Writeln ('Mes: ', x.fecha_nacimiento.mes);
     gotoxy(35,14);
     Writeln ('Día: ', x.fecha_nacimiento.dia);
     gotoxy(35,15);
     Writeln ('Número telefónico: ', x.telefono);
     gotoxy(35,16);
     Writeln ('Obra social: ', x.nombre_obra_social);
     gotoxy(35,17);
     Writeln ('Número de afiliado: ', x.numero_afiliado_obra);
     gotoxy(35,18);
     Writeln ('Estado: ', x.estado);
end;

//----------------------------------------------------------------------------------------------------

procedure inicializar_datos_personas (var x:T_dato_personas);
begin
     x.nombre_apellido := '';
     x.direccion := '';
     x.ciudad := '';
     x.fecha_nacimiento.anio := '';
     x.fecha_nacimiento.mes := '';
     x.fecha_nacimiento.dia := '';
     x.telefono := '';
     x.nombre_obra_social := '';
     x.numero_afiliado_obra := '';
end;

procedure ingresar_datos_personas (var x:T_dato_personas);
begin
     inicializar_datos_personas(x);
     gotoxy(35,6);
     write('Ingrese nombre y apellido: ');
     Readln (x.nombre_apellido);
     gotoxy(35,7);
     write('Ingrese direccion: ');
     Readln (x.direccion);
     gotoxy(35,8);
     write('Ingrese ciudad: ');
     Readln (x.ciudad);
     gotoxy(35,9);
     writeln('Ingrese fecha de nacimiento ');
            gotoxy(35,10);
            write('Ingrese año: ');
            Readln (x.fecha_nacimiento.anio);
            gotoxy(35,11);
            write('Ingrese mes: ');
            Readln (x.fecha_nacimiento.mes);
            gotoxy(35,12);
            write('Ingrese dia: ');
            Readln (x.fecha_nacimiento.dia);
     gotoxy(35,13);
     write('Ingrese telefono: ');
     Readln (x.telefono);
     gotoxy(35,14);
     write('Ingrese nombre de la obra social: ');
     Readln (x.nombre_obra_social);
     gotoxy(35,15);
     write('Ingrese numero de afiliado de la obra: ');
     Readln (x.numero_afiliado_obra);
end;

procedure baja_personas_al_cargar (var arch_personas:T_archivo_personas; pos:T_punt);
var
  x:T_dato_personas;
  resp:char;
begin
     clrscr;
     abrirpersonas (arch_personas);
     Seek (arch_personas,pos^.info.posicion);
     Read (arch_personas,x);
     if x.estado = false then
         begin
         mostrar_datos_personas(x);
         gotoxy(40,20);
         writeln ('Confirma el Alta? s/n');
         gotoxy(68,20);
         readln(resp);
         confirmacion_alta_baja(resp);
         if (resp = 's') or (resp = 'S') then
             begin
             x.estado := true;
             Seek (arch_personas,pos^.info.posicion);
             write (arch_personas,x);
             end;
         end
     else
         begin
         mostrar_datos_personas(x);
         gotoxy(40,20);
         writeln ('Confirma la Baja? s/n');
         gotoxy(68,20);
         readln(resp);
         confirmacion_alta_baja(resp);
         if (resp = 's') or (resp = 'S') then
             begin
             x.estado := false;
             Seek (arch_personas,pos^.info.posicion);
             write (arch_personas,x);
             end;
         end;
     close(arch_personas);
end;

procedure modificacion_personas_al_cargar (var arch_personas:T_archivo_personas; pos:T_punt);
var
  x:T_dato_personas;
  resp:byte;
  resp1:char;
  cancelar:boolean;
begin
     clrscr;
     cancelar := false;
     gotoxy(32,5);
     Writeln ('¿Qué dato desea modificar?');
     gotoxy(35,6);
     writeln ('1- Nombre y Apellido');
     gotoxy(35,7);
     writeln ('2- Dirección');
     gotoxy(35,8);
     writeln ('3- Ciudad');
     gotoxy(35,9);
     writeln ('4- Fecha de Nacimiento');
     gotoxy(35,10);
     writeln ('5- Teléfono');
     gotoxy(35,11);
     writeln ('6- Obra Social');
     gotoxy(35,12);
     writeln ('7- Número Afiliado de Obra');
     gotoxy(35,13);
     writeln ('0- Cancelar');
     gotoxy(35,14);
     write ('Selecione opción: ');
     readln (resp);
     confirmacion_datos_modificacion(resp);
     abrirpersonas (arch_personas);
     Seek (arch_personas,pos^.info.posicion);
     read(arch_personas,x);
     clrscr;
     case resp of
     0: cancelar := true;
     1: begin
        gotoxy(35,5);
        write ('Ingrese nuevo Nombre y Apellido: ');
        readln (x.nombre_apellido);
        end;
     2: begin
        gotoxy(35,5);
        write ('Ingrese nueva Dirección: ');
        readln (x.direccion);
        end;
     3: begin
        gotoxy(35,5);
        write ('Ingrese nueva Ciudad: ');
        readln (x.ciudad);
        end;
     4: begin
        gotoxy(35,5);
        write ('Ingrese nueva Fecha de Nacimiento');
            gotoxy(40,7);
            write('Ingrese año: ');
            Readln (x.fecha_nacimiento.anio);
            write('Ingrese mes: ');
            gotoxy(40,8);
            Readln (x.fecha_nacimiento.mes);
            write('Ingrese dia: ');
            gotoxy(40,9);
            Readln (x.fecha_nacimiento.dia);
        end;
     5: begin
        gotoxy(35,5);
        write ('Ingrese nuevo Teléfono: ');
        readln (x.telefono);
        end;
     6: begin
        gotoxy(35,5);
        write ('Ingrese nueva Obra Social: ');
        readln (x.nombre_obra_social);
        end;
     7: begin
        gotoxy(35,5);
        write ('Ingrese nuevo Número Afiliado de Obra: ');
        readln (x.numero_afiliado_obra);
        end;
     end;
     if cancelar = false then
         begin
         clrscr;
         mostrar_datos_personas(x);
         gotoxy(35,20);
         write('¿Confirma los cambios? s/n');
         gotoxy(66,20);
         readln(resp1);
         confirmacion_cambios(resp1);
         if (resp1 = 's') or (resp1 = 'S') then
             begin
             Seek (arch_personas,pos^.info.posicion);
             write (arch_personas,x);
             end;
         end;
     close(arch_personas);
end;

procedure consulta_personas_al_cargar (var arch_personas:T_archivo_personas; pos:T_punt);
var
   x:T_dato_personas;
begin
     abrirpersonas(arch_personas);
     Seek (arch_personas,pos^.info.posicion);
     Read (arch_personas,x);
     mostrar_datos_personas(x);
     close(arch_personas);
end;

procedure cargar_personas (var arch_personas:T_archivo_personas; var raiz,raiz1:T_punt);
var
  resp:char;
  resp1:byte;
  x:T_dato_personas;
  x2:T_dato_arbol;
  pos:T_punt;
begin
     clrscr;
     gotoxy(35,5);
     writeln ('¿Desea cargar?: s/n');
     gotoxy(60,5);
     Readln (resp);
     confirmacion_datos(resp);
     while (resp = 's') or (resp = 'S') do
     begin
          clrscr;
          gotoxy(35,5);
          write('Ingrese DNI: ');
          Readln (x.dni);
          buscar_al_cargar(raiz,x.dni,pos);
          if pos = nil then
              begin
              if (not arbol_lleno(raiz)) and (not arbol_lleno(raiz1)) then
                  begin
                  abrirpersonas (arch_personas);
                  ingresar_datos_personas(x);
                  x.estado := true;
                  x.posicion := filesize(arch_personas);
                  x2.clave := x.dni;
                  x2.posicion := filesize(arch_personas);
                  Seek (arch_personas,filesize(arch_personas));
                  Write (arch_personas,x);
                  agregar(raiz,x2);
                  x2.clave := x.nombre_apellido;
                  agregar(raiz1,x2);
                  clrscr;
                  gotoxy(30,5);
                  writeln ('¿Desea seguir cargando? s/n');
                  gotoxy(64,5);
                  Readln (resp);
                  confirmacion_datos(resp);
                  close (arch_personas);
                  end;
              end
          else
              begin
              clrscr;
              abrirpersonas(arch_personas);
              Seek (arch_personas,pos^.info.posicion);
              read(arch_personas,x);
              gotoxy(32,5);
              writeln ('La persona ya se encuentra cargada');
              mostrar_datos_personas(x);
              gotoxy(35,20);
              writeln ('¿Qué desea hacer?');
              if x.estado = true then
                  begin
                  gotoxy(35,21);
                  writeln ('1- Baja');
                  end
              else
                  begin
                  gotoxy(35,21);
                  writeln ('1- Alta');
                  end;
              gotoxy(35,22);
              writeln ('2- Modificación');
              gotoxy(35,23);
              writeln ('3- Cargar otra persona');
              gotoxy(35,24);
              writeln ('0- Volver al menú');
              gotoxy(35,25);
              write ('Seleccione opción: ');
              readln (resp1);
              confirmacion_persona_cargada(resp1);
              clrscr;
              close (arch_personas);
              resp := 'n';
              case resp1 of
              1: baja_personas_al_cargar(arch_personas,pos);
              2: modificacion_personas_al_cargar(arch_personas,pos);
              3: resp := 's';
              end;
              end;
     end;
end;

//----------------------------------------------------------------------------------------------------

procedure busqueda_arboles (var arch_personas:t_archivo_personas; resp1:byte; var pos,raiz,raiz1:T_punt; var arch_vacio:boolean; var dni:string);
var
  nombre:string[50];
  x:T_dato_personas;
begin
     clrscr;
     if resp1 = 1 then
         begin
         gotoxy(35,5);
         Write ('Ingrese DNI: ');
         Readln (dni);
         buscar(raiz,pos,arch_vacio,dni);
         end
     else
         begin
         gotoxy(35,5);
         Write ('Ingrese Nombre y Apellido: ');
         Readln (nombre);
         buscar(raiz1,pos,arch_vacio,nombre);
         if pos <> nil then
             begin
             abrirpersonas (arch_personas);
             seek (arch_personas,pos^.info.posicion);
             read (arch_personas,x);
             dni:= x.dni;
             close (arch_personas);
             end;
         end;
end;

procedure baja_logica (var arch_personas:T_archivo_personas; pos:T_punt);
var
  x:T_dato_personas;
  resp:char;
  resp1:byte;
begin
     clrscr;
     gotoxy(35,5);
     write ('1- Alta');
     gotoxy(35,6);
     write ('2- Baja');
     gotoxy(35,7);
     write ('0- Cancelar');
     gotoxy(35,8);
     write ('Seleccione opción: ');
     readln (resp1);
     confirmacion_datos2(resp1);
     abrirpersonas (arch_personas);
     Seek (arch_personas,pos^.info.posicion);
     Read (arch_personas,x);
     clrscr;
     if resp1 = 1 then
         if x.estado = false then
             begin
             mostrar_datos_personas(x);
             gotoxy(40,20);
             writeln ('Confirma el Alta? s/n');
             gotoxy(68,20);
             readln(resp);
             confirmacion_alta_baja(resp);
             if (resp = 's') or (resp = 'S') then
                 begin
                 x.estado := true;
                 Seek (arch_personas,pos^.info.posicion);
                 write (arch_personas,x);
                 end;
             end
         else
             begin
             gotoxy(35,5);
             writeln ('La persona ya está dada de alta');
             readkey;
             end;

     if resp1 = 2 then
         if x.estado = true then
             begin
             mostrar_datos_personas(x);
             gotoxy(40,20);
             writeln ('Confirma la Baja? s/n');
             gotoxy(68,20);
             readln(resp);
             confirmacion_alta_baja(resp);
             if (resp = 's') or (resp = 'S') then
                 begin
                 x.estado := false;
                 Seek (arch_personas,pos^.info.posicion);
                 write (arch_personas,x);
                 end;
             end
         else
             begin
             gotoxy(35,5);
             writeln ('La persona ya está dada de baja');
             readkey;
             end;
     close(arch_personas);
end;

procedure bajapersonas (var arch_personas:T_archivo_personas; var raiz,raiz1:T_punt);
var
  pos:T_punt;
  resp1:byte;
  arch_vacio:boolean;
  dni:string;
begin
     clrscr;
     pos := nil;
     gotoxy(35,5);
     writeln ('1- Alta/Baja por DNI');
     gotoxy(35,6);
     writeln ('2- Alta/Baja por Nombre y Apellido');
     gotoxy(35,7);
     writeln ('0- Cancelar ');
     gotoxy(35,8);
     write ('Seleccione opción: ');
     readln(resp1);
     confirmacion_datos2(resp1);

     if resp1 <> 0 then
         begin
         busqueda_arboles(arch_personas,resp1,pos,raiz,raiz1,arch_vacio,dni);
         if (pos = nil) and (arch_vacio = false) then
             begin
             clrscr;
             gotoxy(35,5);
             writeln ('No se encontró tal DNI');
             readkey;
             end
         else
             if arch_vacio = false then
                 baja_logica(arch_personas,pos);
         end;
end;

//----------------------------------------------------------------------------------------------------

procedure modificacionpersonas (var arch_personas:T_archivo_personas; var raiz,raiz1:T_punt);
var
  pos:T_punt;
  arch_vacio:boolean;
  resp1:byte;
  dni:string;
begin
     clrscr;
     pos := nil;
     gotoxy(35,5);
     writeln ('1- Modificación por DNI');
     gotoxy(35,6);
     writeln ('2- Modificación por Nombre y Apellido');
     gotoxy(35,7);
     writeln ('0- Cancelar');
     gotoxy(35,8);
     write ('Seleccione opción: ');
     readln(resp1);
     confirmacion_datos2(resp1);

     if resp1 <> 0 then
         begin
         busqueda_arboles(arch_personas,resp1,pos,raiz,raiz1,arch_vacio,dni);
         if (pos = nil) and (arch_vacio = false) then
             begin
             clrscr;
             gotoxy(35,5);
             writeln ('No se encontró tal DNI');
             readkey;
             end
         else
             if arch_vacio = false then
                 modificacion_personas_al_cargar(arch_personas,pos);
         end;
end;

//----------------------------------------------------------------------------------------------------

procedure consultapersonas (var arch_personas:T_archivo_personas; var raiz,raiz1:T_punt);
var
   pos:T_punt;
   arch_vacio:boolean;
   resp1:byte;
   dni:string;
begin
     clrscr;
     pos := nil;
     gotoxy(35,5);
     writeln ('1- Consulta por DNI');
     gotoxy(35,6);
     writeln ('2- Consulta por Nombre y Apellido');
     gotoxy(35,7);
     writeln ('0- Cancelar');
     gotoxy(35,8);
     write ('Seleccione opción: ');
     readln(resp1);
     confirmacion_datos2(resp1);

     if resp1 <> 0 then
         begin
         busqueda_arboles(arch_personas,resp1,pos,raiz,raiz1,arch_vacio,dni);
         if (pos = nil) and (arch_vacio = false) then
             begin
             clrscr;
             gotoxy(35,5);
             writeln ('No se encontró tal DNI');
             readkey;
             end
         else
             if arch_vacio = false then
                 begin
                 consulta_personas_al_cargar(arch_personas,pos);
                 readkey;
                 end;
         end;
end;

//----------------------------------------------------------------------------------------------------

procedure consulta_datos_paciente (var arch_personas:T_archivo_personas; var arch_atenciones:T_archivo_atenciones; var raiz,raiz1:T_Punt);
var
   dni:string;
   arch_vacio:boolean;
   x:T_dato_atenciones;
   pos:T_punt;
   pos1:cardinal;
   resp1:byte;
begin
     clrscr;
     pos := nil;
     gotoxy(35,5);
     writeln ('1- Consulta por DNI');
     gotoxy(35,6);
     writeln ('2- Consulta por Nombre y Apellido');
     gotoxy(35,7);
     write ('0- Cancelar');
     gotoxy(35,8);
     write ('Seleccione opción: ');
     readln(resp1);
     confirmacion_datos2(resp1);

     if resp1 <> 0 then
         begin
         busqueda_arboles(arch_personas,resp1,pos,raiz,raiz1,arch_vacio,dni);
         if (pos = nil) and (arch_vacio = false) then
             begin
             clrscr;
             gotoxy(35,5);
             writeln ('No se encontró tal DNI');
             readkey;
             end
         else
             if arch_vacio = false then
                 begin
                 consulta_personas_al_cargar(arch_personas,pos);
                 readkey;
                 abriratenciones(arch_atenciones);
                 pos1 := 0;
                 while not EOF(arch_atenciones) do
                 begin
                      Seek (arch_atenciones,pos1);
                      read (arch_atenciones,x);
                      if x.dni = dni then
                          mostrar_atenciones(x);
                      pos1 := pos1+1;
                 end;
                 close (arch_atenciones);
                 readkey;
                 end;
         end;
end;

//----------------------------------------------------------------------------------------------------

procedure buscar_atenciones (var arch_atenciones: T_archivo_atenciones; dni:string; x2:T_fecha; var x3:T_dato_atenciones; var bandera:boolean);
var
  pos:cardinal;
begin
     abriratenciones (arch_atenciones);
     pos := 0;
     bandera := false;
     while (not EOF (arch_atenciones)) and (bandera = false) do
     begin
          seek (arch_atenciones,pos);
          read (arch_atenciones,x3);
          if (x3.dni = dni) and (x3.fecha.anio + x3.fecha.mes + x3.fecha.dia = x2.anio + x2.mes + x2.dia) then
              begin
              bandera := true;
              end;
          pos:= pos + 1;
     end;
     close (arch_atenciones);
end;

procedure orden_obra_social (var arch_atenciones: T_archivo_atenciones; var arch_personas: T_archivo_personas; var raiz,raiz1:T_Punt);
var
   dni:string;
   resp1:byte;
   pos:T_Punt;
   arch_vacio:boolean;
   x:T_dato_personas;
   x2:T_fecha;
   x3:T_dato_atenciones;
   bandera:boolean;
begin
   clrscr;
     pos := nil;
     gotoxy(35,5);
     writeln ('1- Buscar por DNI');
     gotoxy(35,6);
     writeln ('2- Buscar por Nombre y Apellido');
     gotoxy(35,7);
     writeln ('0- Cancelar');
     gotoxy(35,8);
     write ('Seleccione opción: ');
     readln(resp1);
     confirmacion_datos2(resp1);

     if resp1 <> 0 then
         begin
         busqueda_arboles(arch_personas,resp1,pos,raiz,raiz1,arch_vacio,dni);
         if (pos = nil) and (arch_vacio = false) then
             begin
             clrscr;
             gotoxy(35,5);
             writeln ('No se encontró tal DNI');
             readkey;
             end
         else
             if arch_vacio = false then
                 begin
                 clrscr;
                 gotoxy(35,5);
                 write ('Ingrese fecha de la atención para la orden: ');
                 gotoxy(43,6);
                 write ('Año: ');
                 readln (x2.anio);
                 gotoxy(43,7);
                 write ('Mes: ');
                 readln (x2.mes);
                 gotoxy(43,8);
                 write ('Día: ');
                 readln (x2.dia);
                 abrirpersonas (arch_personas);
                 seek (arch_personas,pos^.info.posicion);
                 read (arch_personas,x);
                 close (arch_personas);
                 buscar_atenciones (arch_atenciones,dni,x2,x3,bandera);
                 if bandera = true then
                     if x.estado = true then
                         cuadro (x,x3)
                     else
                         begin
                         clrscr;
                         gotoxy(35,5);
                         write ('El paciente está dado de baja');
                         readkey;
                         end
                 else
                     begin
                     clrscr;
                     gotoxy(35,5);
                     write ('El paciente no posee atenciones en la fecha ',x2.dia,'/',x2.mes,'/',x2.anio);
                     readkey;
                     end;
                 end;
         end;
end;

END.

