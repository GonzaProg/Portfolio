Unit Menus;

{$codepage UTF8}

INTERFACE

USES
  Crt,Archivo_Personas,Def_Archivo_Personas,Archivo_Atenciones,Def_Archivo_Atenciones,Arboles,Estadisticas,Verificacion_datos;

procedure ABMC_Personas (var raiz,raiz1:T_punt; var arch_personas:T_archivo_personas);
procedure ABMC_Atenciones (var arch_atenciones:T_archivo_atenciones; var raiz:T_punt);
procedure Menu_Estadisticas (var arch_atenciones:T_archivo_atenciones; var arch_personas:T_archivo_personas);


IMPLEMENTATION

procedure ABMC_Personas (var raiz,raiz1:T_punt; var arch_personas:T_archivo_personas);
var
  opcion:byte;
begin
     repeat
     clrscr;
     gotoxy(35,5);
     writeln ('1- Cargar personas');
     gotoxy(35,6);
     writeln ('2- Alta/Baja personas');
     gotoxy(35,7);
     writeln ('3- Modificar personas');
     gotoxy(35,8);
     writeln ('4- Consulta');
     gotoxy(35,9);
     writeln ('0- Volver');
     gotoxy(35,10);
     write ('Seleccione opción: ');
     readln (opcion);
     confirmacion_datos_ABMC_Personas(opcion);
     case opcion of
     1: cargar_personas(arch_personas,raiz,raiz1);
     2: bajapersonas (arch_personas,raiz,raiz1);
     3: modificacionpersonas (arch_personas,raiz,raiz1);
     4: consultapersonas (arch_personas,raiz,raiz1);
     end;
     until opcion = 0;
end;

//----------------------------------------------------------------------------------------------------

procedure ABMC_Atenciones (var arch_atenciones:T_archivo_atenciones; var raiz:T_punt);
var
  opcion:byte;
begin
     repeat
     clrscr;
     gotoxy(35,5);
     writeln ('1- Cargar atenciones ');
     gotoxy(35,6);
     writeln ('2- Consulta atenciones');
     gotoxy(35,7);
     writeln ('0- Volver');
     gotoxy(35,8);
     write ('Seleccione opción: ');
     readln (opcion);
     confirmacion_datos_ABMC_Atenciones(opcion);
     case opcion of
     1: cargar_atenciones (arch_atenciones,raiz);
     2: consultaatenciones (arch_atenciones);
     end;
     until opcion = 0;
end;

//----------------------------------------------------------------------------------------------------

procedure Menu_Estadisticas (var arch_atenciones:T_archivo_atenciones; var arch_personas:T_archivo_personas);
var
  opcion:byte;
begin
     repeat
     clrscr;
     gotoxy(35,5);
     writeln ('1- Cantidad atenciones entre dos fechas');
     gotoxy(35,6);
     writeln ('2- Cantidad de atenciones por obra social');
     gotoxy(35,7);
     writeln ('3- Porcentaje de atenciones por meses');
     gotoxy(35,8);
     writeln ('4- Promedio de atenciones diarias');
     gotoxy(35,9);
     writeln ('5- Porcentaje atenciones a pacientes de otra ciudad');
     gotoxy(35,10);
     writeln ('0- Volver');
     gotoxy(35,11);
     write ('Seleccione opción: ');
     readln (opcion);
     confirmacion_datos_estadisticas(opcion);
     case opcion of
     1: atenciones_entre_fechas(arch_atenciones);
     2: cantidad_atenciones_por_obra(arch_personas);
     3: porcentaje_atenciones_por_meses(arch_atenciones);
     4: mostrar_promedio_atenciones_diarias(arch_atenciones);
     5: porcentaje_atenciones_otra_ciudad(arch_personas);
     end;
     until opcion = 0;
end;

END.

