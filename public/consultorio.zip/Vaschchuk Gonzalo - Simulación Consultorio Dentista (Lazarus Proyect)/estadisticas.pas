Unit Estadisticas;

{$codepage UTF8}

INTERFACE

USES
  Crt,Def_Archivo_Atenciones,Def_Archivo_Personas,listas,U_vectores;

TYPE
  T_fecha = record
    anio: string[4];
    mes: string[2];
    dia: string[2];
  end;

procedure atenciones_entre_fechas (var arch_atenciones:T_archivo_atenciones);
procedure cantidad_atenciones_por_obra (var arch_personas:T_archivo_personas);
procedure porcentaje_atenciones_por_meses (var arch_atenciones:T_archivo_atenciones);
procedure mostrar_promedio_atenciones_diarias (var arch_atenciones:T_archivo_atenciones);
procedure porcentaje_atenciones_otra_ciudad (var arch_personas:T_archivo_personas);

IMPLEMENTATION
procedure mostrar_atenciones_entre_fechas(cont:cardinal; x2,x3:T_fecha);
begin
     clrscr;
     gotoxy(35,5);
     writeln ('La cantidad de atenciones entre ',x2.dia,'/',x2.mes,'/',x2.anio,' y ',x3.dia,'/',x3.mes,'/',x3.anio,' es de: ',cont);
     readkey;
end;

procedure atenciones_entre_fechas (var arch_atenciones:T_archivo_atenciones);
var
  x:T_dato_atenciones;
  x2,x3:T_fecha;
  pos,cont:cardinal;
  bandera:boolean;
begin
     clrscr;
     gotoxy(35,5);
     writeln ('Ingrese fecha de inicio:');
     gotoxy(35,6);
     write ('Año: ');
     readln (x2.anio);
     gotoxy(35,7);
     write ('Mes: ');
     readln (x2.mes);
     gotoxy(35,8);
     write ('Día: ');
     readln (x2.dia);

     clrscr;
     gotoxy(35,5);
     writeln ('Ingrese fecha de fin:');
     gotoxy(35,6);
     write ('Año: ');
     readln (x3.anio);
     gotoxy(35,7);
     write ('Mes: ');
     readln (x3.mes);
     gotoxy(35,8);
     write ('Día: ');
     readln (x3.dia);
     pos := 0;
     cont := 0;
     bandera := false;
     abriratenciones(arch_atenciones);
     while (not EOF(arch_atenciones)) and (bandera = false) do
     begin
          seek(arch_atenciones,pos);
          read(arch_atenciones,x);
          if (x.Fecha.anio + x.Fecha.mes + x.Fecha.dia > x2.anio + x2.mes + x2.dia) and (x.Fecha.anio + x.Fecha.mes + x.Fecha.dia < x3.anio + x3.mes + x3.dia) then
              cont := cont + 1
          else
              begin
              if x.Fecha.anio + x.Fecha.mes + x.Fecha.dia > x3.anio + x3.mes + x3.dia then
                 bandera := true;
              end;
          pos := pos+1;
     end;
     close(arch_atenciones);
     mostrar_atenciones_entre_fechas(cont,x2,x3);
end;

//----------------------------------------------------------------------------------------------------

procedure lista_atenciones_por_obra (var arch_personas:T_archivo_personas; var l:T_lista);
var
  pos:cardinal;
  x:T_dato_personas;
  x2:T_dato;
begin
     crear_lista(l);
     abrirpersonas(arch_personas);
     pos := 0;
     while (not EOF(arch_personas)) and (not lista_llena(l)) do
     begin
          seek(arch_personas,pos);
          read(arch_personas,x);
          x2 := x.nombre_obra_social;
          agregar(l,x2);
          pos := pos+1;
     end;
     close(arch_personas);
end;

procedure mostrar_cantidad_atenciones_por_obra(cont:cardinal; obra:T_dato; var i:word);
begin
     gotoxy(35,5 + 2*i);
     write ('Obra social ',obra);
     gotoxy(35,6 + 2*i);
     write ('Cantidad de atenciones: ',cont);
     i := i+2;
end;

procedure cantidad_atenciones_por_obra (var arch_personas:T_archivo_personas);
var
  l:T_lista;
  x,obra:T_dato;
  cont,final:cardinal;
  i:word;
begin
     clrscr;
     lista_atenciones_por_obra(arch_personas,l);
     obra := '';
     cont := 0;
     i := 0;
     final := 0;
     primero(l);
     while not(fin(l)) do
     begin
          recuperar(l,x);
          final := final + 1;
          if x = obra then
              cont := cont + 1
          else
              begin
              if obra <> '' then
                  mostrar_cantidad_atenciones_por_obra(cont,obra,i);
              obra := x;
              cont := 1;
              end;
          if final = tamanio(l) then
              mostrar_cantidad_atenciones_por_obra(cont,obra,i);
          siguiente (l);
     end;
     readkey;
end;

//----------------------------------------------------------------------------------------------------

procedure contador_vector (var vec:T_vector; mes:string);
begin
     Case mes of
              '1','01': begin
                        vec[1].cant_atenciones := vec[1].cant_atenciones+1;
                        vec[1].mes := 'Enero';
                        end;
              '2','02': begin
                        vec[2].cant_atenciones := vec[2].cant_atenciones+1;
                        vec[2].mes := 'Febrero';
                        end;
              '3','03': begin
                        vec[3].cant_atenciones := vec[3].cant_atenciones+1;
                        vec[3].mes := 'Marzo';
                        end;
              '4','04': begin
                        vec[4].cant_atenciones := vec[4].cant_atenciones+1;
                        vec[4].mes := 'Abril';
                        end;
              '5','05': begin
                        vec[5].cant_atenciones := vec[5].cant_atenciones+1;
                        vec[5].mes := 'Mayo';
                        end;
              '6','06': begin
                        vec[6].cant_atenciones := vec[6].cant_atenciones+1;
                        vec[6].mes := 'Junio';
                        end;
              '7','07': begin
                        vec[7].cant_atenciones := vec[7].cant_atenciones+1;
                        vec[7].mes := 'Julio';
                        end;
              '8','08': begin
                        vec[8].cant_atenciones := vec[8].cant_atenciones+1;
                        vec[8].mes := 'Agosto';
                        end;
              '9','09': begin
                        vec[9].cant_atenciones := vec[9].cant_atenciones+1;
                        vec[9].mes := 'Septiembre';
                        end;
              '10': begin
                        vec[10].cant_atenciones := vec[10].cant_atenciones+1;
                        vec[10].mes := 'Octubre';
                        end;
              '11': begin
                        vec[11].cant_atenciones := vec[11].cant_atenciones+1;
                        vec[11].mes := 'Noviembre';
                        end;
              '12': begin
                        vec[12].cant_atenciones := vec[12].cant_atenciones+1;
                        vec[12].mes := 'Diciembre';
                        end;
              end;
end;

procedure mostrar_porcentaje_atenciones_por_meses (var vec:T_vector; total:cardinal; aux:boolean);
var
  porcen:real;
  i:1..12;
  j:word;
begin
     clrscr;
     j := 0;
     if (total <> 0) and (aux = true) then
         begin
         for i := 1 to 12 do
         begin
              if vec[i].cant_atenciones <> 0 then
                  begin
                       porcen := (vec[i].cant_atenciones/total)*100;
                       gotoxy(35,5 + 2*j);
                       write ('Mes ',vec[i].mes);
                       gotoxy(35,6 + 2*j);
                       write ('Porcentaje de atenciones: ',porcen:3:2,'%');
                       j := j+2;
                  end;
         end;
         end
     else
         begin
              gotoxy(35,5);
              write ('No se ha realizado ninguna atención este año');
         end;
end;

procedure porcentaje_atenciones_por_meses (var arch_atenciones:T_archivo_atenciones);
var
  pos,total:cardinal;
  x:T_dato_atenciones;
  anio:string[4];
  vec:T_vector;
  aux:boolean;
begin
     clrscr;
     pos := 0;
     total:= 0;
     aux := false;
     inicializar(vec);
     abriratenciones(arch_atenciones);
     gotoxy(35,5);
     write ('Ingrese año actual: ');
     readln (anio);
     while not EOF(arch_atenciones) do
     begin
          seek(arch_atenciones,pos);
          read(arch_atenciones,x);
          if (x.Fecha.anio = anio) then
              begin
              total := total + 1 ;
              aux := true;
              contador_vector(vec,x.fecha.mes);
              end;
          pos := pos+1;
     end;
     mostrar_porcentaje_atenciones_por_meses(vec,total,aux);
     close(arch_atenciones);
     readkey;
end;

//----------------------------------------------------------------------------------------------------

procedure eleccion_mes_para_promedio (cont:cardinal; mes:string; var promedio:real);
begin
 case mes of
   '1','01','3','03','5','05','7','07','8','08','10','12': promedio := (cont/31);
   '4','04','6','06','9','09','11': promedio := (cont/30);
   '2','02': promedio := (cont/28);
 end;
end;

procedure promedio_atenciones_diarias (var arch_atenciones:T_archivo_atenciones; var promedio:real);
var
mes:string[2];
anio:string[4];
pos:cardinal;
x:T_dato_atenciones;
bandera:boolean;
cont:cardinal;
begin
     clrscr;
     gotoxy(35,5);
     write ('Ingrese año en el que desea calcular el promedio: ');
     Readln (anio);
     gotoxy(35,7);
     write ('Ingrese mes en el que desea calcular el promedio: ');
     Readln (mes);
     pos:= 0;
     cont := 0;
     promedio := 0;
     bandera:= false;
     abriratenciones(arch_atenciones);
     while not (EOF(arch_atenciones)) and (bandera = false) do
     begin
          seek(arch_atenciones,pos);
          read(arch_atenciones,x);
          if (x.fecha.anio = anio) and (x.fecha.mes = mes) then
              cont := cont + 1;
          if (x.fecha.anio + x.fecha.mes > anio + mes) then
              bandera := true ;
          pos := pos + 1;
     end;
     close(arch_atenciones);
     eleccion_mes_para_promedio(cont,mes,promedio);
end;

procedure mostrar_promedio_atenciones_diarias (var arch_atenciones:T_archivo_atenciones);
var
promedio:real;
begin
     promedio_atenciones_diarias(arch_atenciones,promedio);
     clrscr;
     gotoxy(35,5);
     write ('El promedio de atenciones es: ',promedio:4:2);
     readkey;
end;

//----------------------------------------------------------------------------------------------------

procedure mostrar_porcentaje_atenciones_otra_ciudad (cont,total:cardinal);
begin
     clrscr;
     gotoxy(35,5);
     write ('El Porcentaje de Atenciones a Pacientes de Otra Ciudad es de: ',cont*100/total:4:2,'%');
end;

procedure porcentaje_atenciones_otra_ciudad (var arch_personas:T_archivo_personas);
var
  x:T_dato_personas;
  pos,cont,total:cardinal;
begin
     pos := 0;
     cont := 0;
     abrirpersonas(arch_personas);
     total := filesize(arch_personas);
     while not EOF(arch_personas) do
     begin
          seek(arch_personas,pos);
          read(arch_personas,x);
          if UpCase(x.ciudad) <> 'concepcion del uruguay' then
              cont := cont + 1;
              pos := pos + 1 ;
     end;
     if total <> 0 then
         mostrar_porcentaje_atenciones_otra_ciudad(cont,total);
     close(arch_personas);
     readkey;
end;

END.

