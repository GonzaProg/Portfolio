Unit Archivo_Atenciones;

{$codepage UTF8}

INTERFACE

USES
  Crt, Def_Archivo_Atenciones, Usar_Arboles, Arboles, Estadisticas, Verificacion_datos;

procedure cargar_atenciones (var arch_atenciones:T_archivo_atenciones; var raiz:T_punt);
procedure consultaatenciones (var arch_atenciones:T_archivo_atenciones);
procedure listado_ordenado_paciente (var arch_atenciones:T_archivo_atenciones);
procedure fecha_todas_atenciones (var arch_atenciones:T_archivo_atenciones);
procedure mostrar_atenciones(x:T_dato_atenciones);


IMPLEMENTATION

procedure buscar_fecha_atencion (var arch_atenciones:T_archivo_atenciones; x:T_dato_atenciones; var x2:T_dato_atenciones; var encontrado:boolean);
var
  pos:cardinal;
begin
     pos := 0;
     encontrado := false;
     while (not EOF(arch_atenciones)) and (encontrado = false) do
     begin
          seek(arch_atenciones,pos);
          read(arch_atenciones,x2);
          if (x2.DNI = x.dni) and (x.Fecha.anio + x.Fecha.mes + x.Fecha.dia = x2.Fecha.anio + x2.Fecha.mes + x2.Fecha.dia) then
              encontrado := true;
          pos := pos + 1;
     end;
end;

procedure ingresar_datos_atenciones (var arch_atenciones:T_archivo_atenciones; var x,x2:T_dato_atenciones; var encontrado:boolean);
var
  pos:0..n;
  resp:char;
begin
     pos := 0;
     gotoxy(35,7);
     writeln ('Ingrese fecha: ');
         gotoxy(35,8);
         write ('Ingrese año: ');
         readln (x.Fecha.anio);
         gotoxy(35,9);
         write ('Ingrese mes: ');
         readln (x.Fecha.mes);
         gotoxy(35,10);
         write ('Ingrese día: ');
         readln (x.Fecha.dia);
     buscar_fecha_atencion(arch_atenciones,x,x2,encontrado);
     if encontrado = true then
         begin
         repeat
         clrscr;
         pos := pos + 1;
         if x2.tratamiento[pos].codigo = '' then
             begin
             gotoxy(35,11);
             write ('Ingrese código de tratamiento: ');
             Readln (x2.tratamiento[pos].codigo);
             gotoxy(35,12);
             write ('Ingrese descripción del tratamiento: ');
             Readln (x2.tratamiento[pos].descripcion);
             if pos <> n then
                 begin
                 gotoxy(35,14);
                 write ('Desea cargar otro tratamiento? s/n');
                 gotoxy(75,14);
                 readln (resp);
                 confirmacion_tratamientos(resp);
                 end
             else
                 begin
                 gotoxy(35,14);
                 write ('El paciente alcanzó el máximo de atenciones diarias');
                 readkey;
                 end;
             end;
         until (resp = 'n') or (resp = 'N') or (pos = n);
         end
     else
         begin
              repeat
              clrscr;
              pos := pos + 1;
              gotoxy(35,11);
              write ('Ingrese código de tratamiento: ');
              Readln (x.tratamiento[pos].codigo);
              gotoxy(35,12);
              write ('Ingrese descripción del tratamiento: ');
              Readln (x.tratamiento[pos].descripcion);
              if pos <> n then
                 begin
                 gotoxy(35,14);
                 write ('Desea cargar otro tratamiento? s/n');
                 gotoxy(75,14);
                 readln (resp);
                 confirmacion_tratamientos(resp);
                 end
             else
                 begin
                 gotoxy(35,14);
                 write ('El paciente alcanzó el máximo de atenciones diarias');
                 readkey;
                 end;
              until (resp = 'n') or (resp = 'N') or (pos = n);
         end;
 end;

procedure inicializarconsulta (var x:T_dato_atenciones  );
var
   i:1..n;
begin
     For i := 1 to n do
     begin
          x.tratamiento[i].codigo := '';
          x.tratamiento[i].descripcion := '';
     end;
end;

//----------------------------------------------------------------------------------------------------

procedure cargar_atenciones (var arch_atenciones:T_archivo_atenciones; var raiz:T_punt);
var
  x,x2:T_Dato_Atenciones;
  pos:T_punt;
  encontrado:boolean;
begin
     clrscr;
     gotoxy(35,5);
     write ('Ingrese DNI: ');
     Readln (x.dni);
     buscar_al_cargar(raiz,x.dni,pos);
     if pos <> nil then
         begin
         abriratenciones (arch_atenciones);
         inicializarconsulta (x);
         ingresar_datos_atenciones (arch_atenciones,x,x2,encontrado);
         if encontrado = false then
             begin
             x.posicion := filesize(arch_atenciones);
             seek (arch_atenciones,filesize(arch_atenciones));
             write (arch_atenciones,x);
             end
         else
             begin
             seek (arch_atenciones,x2.posicion);
             write (arch_atenciones,x2);
             end;
         close (arch_atenciones);
         end
     else
         begin
              clrscr;
              gotoxy(35,5);
              write ('No se encontró la persona, primero debe cargarla');
              readkey;
         end;
end;

//----------------------------------------------------------------------------------------------------
procedure mostrar_consulta(x:T_dato_atenciones; k:byte);
begin
     clrscr;
     gotoxy(35,2);
     write ('DNI: ', x.dni);
     gotoxy(35,3);
     write ('Fecha: ');
     gotoxy(35,4);
     write ('Año: ', x.fecha.anio);
     gotoxy(35,5);
     write ('Mes: ', x.fecha.mes);
     gotoxy(35,6);
     write ('Día: ', x.fecha.dia);
     gotoxy(35,8);
     write ('Tratamiento ', k);
     gotoxy(35,9);
     write ('Código: ', x.Tratamiento[k].codigo);
     gotoxy(35,10);
     write ('Descripción: ', x.Tratamiento[k].descripcion);
end;

procedure consultaatenciones (var arch_atenciones:T_archivo_atenciones);
var
  dni:string[10];
  codigo:string[30];
  x:T_Dato_Atenciones;
  x2:T_fecha;
  i:cardinal;
  k:1..n+1;
  encontrado,encontrado2,bandera:boolean;
begin
     clrscr;
     k := 1;
     i := 0;
     bandera := false;
     encontrado := false;
     encontrado2 := false;
     gotoxy(35,5);
     write ('Ingrese el DNI: ');
     Readln (dni);
     gotoxy(35,6);
     write ('Ingrese Fecha de Atención: ');
     gotoxy(35,7);
     write ('Año: ');
     readln (x2.anio);
     gotoxy(35,8);
     write ('Mes: ');
     readln (x2.mes);
     gotoxy(35,9);
     write ('Día: ');
     readln (x2.dia);
     gotoxy(35,10);
     write ('Ingrese código de tratamiento: ');
     Readln (codigo);
     abriratenciones (arch_atenciones);
     while not EOF(arch_atenciones) do
     begin
          seek (arch_atenciones,i);
          read (arch_atenciones,x);
          if (x.DNI = dni) then
              begin
                   encontrado := true;
                   if x.fecha.anio + x.fecha.mes + x.fecha.dia = x2.anio + x2.mes + x2.dia then
                       begin
                       while (k <> n+1) and (bandera = false) do
                       begin
                            if x.Tratamiento[k].codigo = codigo then
                                begin
                                     encontrado2 := true;
                                     bandera := true;
                                     mostrar_consulta (x,k);
                                end;
                            k := k + 1;
                       end;
                       end;
              end;
          i := i + 1;
     end;
     if encontrado = false then
         begin
         clrscr;
         gotoxy(35,5);
         writeln ('No se encontró tal DNI');
         end;
     if encontrado2 = false then
         begin
         clrscr;
         gotoxy(35,5);
         writeln ('No se encontró el código de atención deseado');
         end;
     Close (arch_atenciones);
     readkey;
end;

//----------------------------------------------------------------------------------------------------

procedure mostrar_atenciones(x:T_dato_atenciones);
var
  k:1..n+1;
  i,j,aux:byte;
  bandera:boolean;
begin
     clrscr;
     k := 1;
     i := 1;
     j := 2;
     aux := 0;
     bandera := false;
     gotoxy(55,2);
     write ('DNI: ', x.dni);
     gotoxy(52,3);
     write ('----Fecha----');
     gotoxy(54,4);
     write ('Año: ', x.fecha.anio);
     gotoxy(54,5);
     write ('Mes: ', x.fecha.mes);
     gotoxy(54,6);
     write ('Día: ', x.fecha.dia);
     while (k <> n+1) and (bandera = false) do
     begin
          if x.Tratamiento[k].codigo <> '' then
              begin
              aux := aux + 1;
              gotoxy(52,2 + j + 4*i);
              write ('Tratamiento ', k);
              gotoxy(52,3 + j + 4*i);
              write ('Código: ', x.Tratamiento[k].codigo);
              gotoxy(52,4 + j + 4*i);
              write ('Descripción: ', x.Tratamiento[k].descripcion);
              i := i+1;
              k := k+1;
              if aux = 5 then
                  begin
                  readkey;
                  clrscr;
                  j := 0;
                  i := 0;
                  aux := 0;
                  end;
              end
          else
              bandera := true;
     end;
     readkey;
end;

procedure fecha_todas_atenciones (var arch_atenciones:T_archivo_atenciones);
var
  x:T_dato_atenciones;
  i:cardinal;
begin
     clrscr;
     abriratenciones (arch_atenciones);
     i := 0;
     while not EOF(arch_atenciones) do
     begin
          Seek (arch_atenciones,i);
          Read (arch_atenciones,x);
          mostrar_atenciones(x);
          i := i+1;
     end;
     close(arch_atenciones);
     Readkey;
end;

//----------------------------------------------------------------------------------------------------
procedure listado_ordenado_paciente (var arch_atenciones:T_archivo_atenciones);
var
  dni:string[10];
  x:T_dato_atenciones;
  i:cardinal;
  encontrado:boolean;
begin
     clrscr;
     gotoxy(35,5);
     write ('Ingrese el DNI: ');
     Readln (dni);
     abriratenciones (arch_atenciones);
     i := 0;
     encontrado := false;
     while not EOF(arch_atenciones) do
     begin
          seek (arch_atenciones,i);
          read (arch_atenciones,x);
          if x.dni = dni then
              begin
              mostrar_atenciones(x);
              encontrado := true;
              end;
          i := i+1;
     end;
     close (arch_atenciones);
     if encontrado = false then
         begin
         clrscr;
         gotoxy(35,5);
         writeln ('No se encontró tal DNI');
         end;
     readkey;
end;

END.

