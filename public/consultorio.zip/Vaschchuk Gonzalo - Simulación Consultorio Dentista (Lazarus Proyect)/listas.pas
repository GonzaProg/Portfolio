Unit listas;

INTERFACE

USES
crt;

TYPE
T_dato = string[30];

T_punt2 = ^nodo;

nodo = record
info: T_dato;
sig: T_punt2;
end;

T_lista = record
cab: T_punt2;
act: T_punt2;
tamanio: cardinal;
end;

procedure crear_lista(var l:T_lista);
procedure agregar (var l:T_lista; x:T_dato);
function tamanio (var l:T_lista):cardinal;
function lista_vacia(var l:T_lista):boolean;
function lista_llena(var l:T_lista):boolean;
function fin(var l:T_lista): boolean;
procedure primero(var l:T_lista);
procedure recuperar (var l:T_lista; var x:T_dato);
procedure siguiente (var l:T_lista);

IMPLEMENTATION

procedure crear_lista(var l:T_lista);
begin
	l.cab:= nil;
	l.tamanio:= 0;
end;

procedure agregar (var l:T_lista; x:T_dato);
var
dir,ant:T_punt2;
begin
new (dir);
dir^.info:= x;
if (l.cab = nil) or (l.cab^.info > x) then
	begin
	dir^.sig:= l.cab;
	l.cab:= dir;
	end
else
	begin
	ant := l.cab;
	l.act := l.cab^.sig;
	while (l.act <> nil) and (l.act^.info < x) do
        begin
        	ant:= l.act;
                l.act:= l.act^.sig;
        end;
	dir^.sig:= ant^.sig;
	ant^.sig:= dir;
	end;
inc(l.tamanio);
end;

function tamanio (var l:T_lista):cardinal;
begin
	tamanio:= l.tamanio;
end;

function lista_vacia(var l:T_lista):boolean;
begin
	lista_vacia := l.tamanio =0;
end;

function lista_llena(var l:T_lista):boolean;
begin
	lista_llena := getheapstatus.totalfree < sizeof(nodo);
end;

function fin(var l:T_lista): boolean;
begin
	fin:= l.act = nil;
end;

procedure primero(var l:T_lista);
begin
	l.act:= l.cab
end;

procedure recuperar (var l:T_lista; var x:T_dato);
begin
	x:= l.act^.info;
end;

procedure siguiente (var l:T_lista);
begin
	l.act:= l.act^.sig;
end;

END.
