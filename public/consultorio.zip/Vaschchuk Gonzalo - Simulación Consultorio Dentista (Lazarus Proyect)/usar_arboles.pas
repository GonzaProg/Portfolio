Unit Usar_Arboles;

INTERFACE
{$codepage UTF8}

USES
   crt, Arboles,Def_Archivo_Atenciones;

procedure buscar (raiz:T_punt; var pos:T_punt; var arch_vacio:boolean; buscado:string);
procedure buscar_al_cargar (raiz:T_punt; buscado:string; var pos:T_punt);
function preorden (raiz:T_punt; buscado:string ):T_punt;

IMPLEMENTATION

procedure buscar_al_cargar (raiz:T_punt; buscado:string; var pos:T_punt);
begin
     pos := preorden (raiz,buscado);
end;

procedure buscar (raiz:T_punt; var pos:T_punt; var arch_vacio:boolean; buscado:string);
begin
     arch_vacio := false;
     if arbol_vacio (raiz) then
         begin
         write ('Archivo vacío (No hay ninguna persona cargada)');
         arch_vacio := true;
         readkey;
         end
     else
         pos := preorden (raiz,buscado);
end;

function preorden (raiz:T_punt; buscado:string ):T_punt;
begin
     if (raiz =  nil) then
         preorden := nil
     else
	 if (raiz^.info.clave  = buscado) then
             preorden:= raiz
         else
	     if raiz^.info.clave > buscado then
                 preorden := preorden(raiz^.sai,buscado)
             else
                 preorden := preorden(raiz^.sad,buscado);
end;

END.
