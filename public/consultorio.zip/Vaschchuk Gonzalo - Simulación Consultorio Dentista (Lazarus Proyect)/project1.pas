Program project1;
 
{$codepage UTF8}

USES CRT, Menus, Def_Archivo_Personas, Def_Archivo_Atenciones, Arboles,
  Archivo_Personas, Archivo_Atenciones, Verificacion_datos;

VAR
  opcion:byte;
  raiz,raiz1:T_punt;
  arch_personas:T_archivo_personas;
  arch_atenciones:T_archivo_atenciones;

begin
 crear_arbol (raiz);
 crear_arbol (raiz1);
 pasarpersonas(raiz,raiz1,arch_personas);
 repeat
 clrscr;
 gotoxy(35,5);
 writeln ('1- ABMC de Personas');
 gotoxy(35,6);
 writeln ('2- ABMC de Atenciones');
 gotoxy(35,7);
 writeln ('3- Listado por fecha de todas las atenciones');
 gotoxy(35,8);
 writeln ('4- Listado por fecha de atenciones a un paciente');
 gotoxy(35,9);
 writeln ('5- Consultar datos de un paciente');
 gotoxy(35,10);
 writeln ('6- Imprimir orden para obra social');
 gotoxy(35,11);
 writeln ('7- Estadísticas');
 gotoxy(35,12);
 writeln ('0- Salir');
 gotoxy(35,13);
 write ('Seleccione opción: ');
 readln (opcion);
 confirmacion_datos_menu(opcion);
 case opcion of
 1: ABMC_Personas(raiz,raiz1,arch_personas);
 2: ABMC_Atenciones(arch_atenciones,raiz);
 3: fecha_todas_atenciones (arch_atenciones);
 4: listado_ordenado_paciente (arch_atenciones);
 5: consulta_datos_paciente(arch_personas,arch_atenciones,raiz,raiz1);
 6: orden_obra_social (arch_atenciones,arch_personas,raiz,raiz1);
 7: Menu_Estadisticas(arch_atenciones,arch_personas);
 end;
 until opcion = 0;

END.


