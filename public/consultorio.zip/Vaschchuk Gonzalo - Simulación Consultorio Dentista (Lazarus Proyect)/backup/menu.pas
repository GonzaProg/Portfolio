unit Menu;

{$codepage UTF8}

interface

uses
  Crt,Extras,Def_Archivo_Personas,Arboles,Usar_Arboles;

implementation
procedure ABMC_Personas ();
var
  arch_personas:T_archivo_personas;
  raiz:T_punt;
  opcion:byte;
begin
     crear_arbol (raiz);
     pasarpersonas(raiz,arch_personas);
     repeat
     clrscr;
     writeln ('1- Cargar personas');
     writeln ('2- Mostrar');
     writeln ('3- Baja personas');
     writeln ('4- Modificar personas');
     writeln ('5- Consulta');
     writeln ('0- Salir');
     writeln ('Seleccione opción: ');
     readln (opcion);
     case opcion of
     1: cargar_personas(arch_personas,raiz);
     2: mostrarfurioso (arch_personas);
     3: bajapersonas (arch_personas,raiz);
     4: modificacionpersonas (arch_personas,raiz);
     5: consultapersonas (arch_personas,raiz);
     end;
     until opcion = 0;
end;

end.

