Unit Def_Archivo_Atenciones;

INTERFACE

USES
  Crt;

CONST
  ruta_atenciones = 'D:\ARCHIVOS\atenciones.dat';
  n = 8;

TYPE

T_dato_tratamiento = record
codigo: string[30];
descripcion: string[255];
end;

T_dato_atenciones = record
DNI: string[10];
Fecha: record
             anio: string[4];
             mes: string[2];
             dia: string[2];
       end;
Tratamiento: array [1..n] of T_dato_tratamiento;
posicion:cardinal;
end;

T_archivo_atenciones = file of T_dato_atenciones;

procedure abriratenciones (var arch_atenciones:T_archivo_atenciones);

IMPLEMENTATION

procedure abriratenciones (var arch_atenciones:T_archivo_atenciones);
begin
  assign (arch_atenciones,ruta_atenciones);
     {$i-}
     reset (arch_atenciones);
     {$i+}
     if IOResult <> 0 then
         rewrite(arch_atenciones);
end;

END.

