unit Extras;

{$codepage UTF8}

INTERFACE

uses
  Crt,Def_Archivo_Personas,Def_Archivo_Atenciones,Arboles,Usar_Arboles;

procedure cargar_personas (var arch_personas:T_archivo_personas; var raiz:T_punt);
procedure mostrarfurioso (var arch_personas:t_archivo_personas);
procedure bajapersonas (var arch_personas:t_archivo_personas; var raiz:T_punt);
procedure modificacionpersonas (var arch_personas:t_archivo_personas; var raiz:T_punt);
procedure consultapersonas (var arch_personas:t_archivo_personas; var raiz:T_punt);
procedure pasarpersonas(var raiz:T_punt; var arch_personas:t_archivo_personas);

IMPLEMENTATION

procedure confirmacion_datos (var resp:char);
begin
     while (resp <> 's') and (resp <> 'S') and (resp <> 'n') and (resp <> 'N') do
     begin
          writeln ('Debe ingresar "s" o "n"');
          writeln ('Pruebe de nuevo: ');
          readln(resp);
     end;
end;

procedure inicializar_datos_personas (var x:T_dato_personas);
begin
     x.nombre_apellido := '';
     x.dni := '';
     x.direccion := '';
     x.ciudad := '';
     x.fecha_nacimiento.anio := '';
     x.fecha_nacimiento.mes := '';
     x.fecha_nacimiento.dia := '';
     x.telefono := '';
     x.nombre_obra_social := '';
     x.numero_afiliado_obra := '';
end;

procedure ingresar_datos_personas (var x:T_dato_personas);
begin
     inicializar_datos_personas(x);
     writeln('Ingrese nombre y apellido: ');
     Readln (x.nombre_apellido);
     writeln('Ingrese DNI: ');
     Readln (x.dni);
     writeln('Ingrese direccion: ');
     Readln (x.direccion);
     writeln('Ingrese ciudad: ');
     Readln (x.ciudad);
     writeln('Ingrese fecha de nacimiento ');
            write('Ingrese año: ');
            Readln (x.fecha_nacimiento.anio);
            write('Ingrese mes: ');
            Readln (x.fecha_nacimiento.mes);
            write('Ingrese dia: ');
            Readln (x.fecha_nacimiento.dia);
     writeln('Ingrese telefono: ');
     Readln (x.telefono);
     writeln('Ingrese nombre de la obra social: ');
     Readln (x.nombre_obra_social);
     writeln('Ingrese numero de afiliado de la obra: ');
     Readln (x.numero_afiliado_obra);
end;

procedure cargar_personas (var arch_personas:T_archivo_personas; var raiz:T_punt);
var
  resp:char;
  x:T_dato_personas;
begin
     writeln ('¿Desea cargar?: s/n');
     Readln (resp);
     confirmacion_datos(resp);
     while (resp = 's') or (resp = 'S') do
     begin
          abrirpersonas (arch_personas);
          ingresar_datos_personas(x);
          x.estado := true;
          x.posicion:= filesize(arch_personas);
          Seek (arch_personas,filesize(arch_personas));
          Write (arch_personas,x);
          agregar (raiz,x);
          writeln ('¿Desea continuar?: s/n');
          Readln (resp);
          confirmacion_datos(resp);
          if (resp = 'n') or (resp = 'N') then
              close (arch_personas);
     end;
end;

procedure mostrar_datos_personas (x:T_dato_personas);
begin
     Writeln ('Nombre y apellido: ', x.nombre_apellido);
     Writeln ('Dirección: ', x.direccion);
     Writeln ('Ciudad: ', x.ciudad);
     Writeln ('DNI: ', x.dni);
     Writeln ('Fecha de nacimiento: ');
     Writeln ('Año: ', x.fecha_nacimiento.anio);
     Writeln ('Mes: ', x.fecha_nacimiento.mes);
     Writeln ('Día: ', x.fecha_nacimiento.dia);
     Writeln ('Número telefónico: ', x.telefono);
     Writeln ('Obra social: ', x.nombre_obra_social);
     Writeln ('Número de afiliado: ', x.numero_afiliado_obra);
     Writeln ('Estado: ', x.estado);
end;

procedure bajapersonas (var arch_personas:t_archivo_personas; var raiz:T_punt);
var
  pos:T_punt;
  x:T_dato_personas;
  resp: char;
  arch_vacio:boolean;
begin
pos := nil;
buscar(raiz,pos,arch_vacio);
if (pos = nil) and (arch_vacio = false) then
    begin
    writeln ('No se encontró tal DNI');
    readkey;
    end
else
    if arch_vacio = false then
    begin
         abrirpersonas (arch_personas);
         Seek (arch_personas,pos^.info.posicion);
         Read (arch_personas,x);
         mostrar_datos_personas(x);
         writeln ('Confirma la baja? s/n');
         readln(resp);
         confirmacion_datos(resp);
         if (resp = 's') or (resp = 'S') then
         begin
              x.estado := false;
              Seek (arch_personas,pos^.info.posicion);
              write (arch_personas,x);
              pos^.info:= x ;
         end;
         close(arch_personas);
    end;
end;

procedure mostrarfurioso (var arch_personas:t_archivo_personas);
var
  x:T_dato_personas;
  i:cardinal;
begin
abrirpersonas (arch_personas);
For i:= 0 to filesize(arch_personas)-1 do
     begin
      Seek (arch_personas,i);
      Read (arch_personas,x);
      Writeln (x.nombre_apellido);
      Writeln (x.estado);
      Writeln ();
     end;
close(arch_personas);
Readkey;
end;

 procedure modificacionpersonas (var arch_personas:t_archivo_personas; var raiz:T_punt);
var
  pos:T_punt;
  x:T_dato_personas;
  arch_vacio:boolean;
begin
pos := nil;
buscar(raiz,pos,arch_vacio);
if (pos = nil) and (arch_vacio = false) then
    begin
    writeln ('No se encontró tal DNI');
    readkey;
    end
else
    if arch_vacio = false then
    begin
         Writeln ('Ingrese nuevos datos: ');
         ingresar_datos_personas(x);
         x.estado := pos^.info.estado;
         x.posicion := pos^.info.posicion;
         abrirpersonas (arch_personas);
         Seek (arch_personas,pos^.info.posicion);
         write (arch_personas,x);
         close(arch_personas);
         pos^.info:= x ;
    end;
end;

procedure consultapersonas (var arch_personas:t_archivo_personas; var raiz:T_punt);
var
   x:T_dato_personas;
   pos:T_punt;
   arch_vacio:boolean;
begin
     pos := nil;
     buscar (raiz,pos,arch_vacio);
     if (pos = nil) and (arch_vacio = false) then
         begin
         writeln ('No se encontró tal DNI');
         readkey;
         end
     else
         if arch_vacio = false then
         begin
              abrirpersonas(arch_personas);
              Seek (arch_personas,pos^.info.posicion);
              Read (arch_personas,x);
              mostrar_datos_personas(x);
              close(arch_personas);
              readkey;
         end;
end;

procedure pasarpersonas(var raiz:T_punt; var arch_personas:t_archivo_personas);
var
   pos:cardinal;
   x:T_dato_personas;
begin
     abrirpersonas (arch_personas);
     pos := 0;
     while not EOF(arch_personas) do
     begin
          Seek (arch_personas,pos);
          read (arch_personas,x);
          agregar (raiz,x);
          pos:= pos+1;
     end;
     Close (arch_personas);
end ;

end.

