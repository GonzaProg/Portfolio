Unit Cuadro_de_Atenciones;

{$codepage UTF8}

interface

uses
crt,Def_archivo_atenciones,Def_Archivo_Personas;

procedure cuadro (x:T_dato_personas; x3:T_dato_atenciones);

Implementation

procedure cuadro (x:T_dato_personas; x3:T_dato_atenciones);
var
  i,j:byte;
  bandera:boolean;
begin
     clrscr;
     gotoxy(21,3);
     write ('————————————————————————————————————————————————————————————————————————————————');

     gotoxy(55,4);
     write ('DNI: ',x.dni);

     gotoxy(20,4);
     write ('|');
     gotoxy(20,5);
     write ('|');
     gotoxy(20,6);
     write ('|');
     gotoxy(20,7);
     write ('|');
     gotoxy(20,8);
     write ('|');
     gotoxy(20,9);
     write ('|');
     gotoxy(20,10);
     write ('|');
     gotoxy(20,11);
     write ('|');
     gotoxy(20,12);
     write ('|');
     gotoxy(20,13);
     write ('|');
     gotoxy(20,14);
     write ('|');
     gotoxy(20,15);
     write ('|');
     gotoxy(20,16);
     write ('|');
     gotoxy(20,17);
     write ('|');
     gotoxy(20,18);
     write ('|');
     gotoxy(20,19);
     write ('|');
     gotoxy(20,20);
     write ('|');
     gotoxy(20,21);
     write ('|');
     gotoxy(20,22);
     write ('|');
     gotoxy(20,23);
     write ('|');
     gotoxy(20,24);
     write ('|');
     gotoxy(20,25);
     write ('|');
     gotoxy(20,26);
     write ('|');

     gotoxy(21,6);
     write ('OBRA SOCIAL: ', x.nombre_obra_social);

     gotoxy(70,6);
     write ('|');
     gotoxy(72,6);
     write ('NRO AFILIADO: ', x.numero_afiliado_obra);

     gotoxy(21,5);
     write ('————————————————————————————————————————————————————————————————————————————————');

     gotoxy(21,8);
     write ('NOMBRE: ', x.nombre_apellido);
     gotoxy(70,8);
     write ('|');
     gotoxy(72,8);
     write ('FECHA: ', x3.Fecha.dia,'/',x3.Fecha.mes,'/',x3.Fecha.anio);

     gotoxy(21,7);
     write ('————————————————————————————————————————————————————————————————————————————————');

     gotoxy(21,9);
     write ('————————————————————————————————————————————————————————————————————————————————');

     gotoxy(21,10);
     write ('CODIGO');
     gotoxy(55,10);
     write ('DETALLE DE ATENCION');
     j := 0;
     i := 1;
     bandera := false;
     while (i <> n+1) and (bandera = false) do
     begin
          if x3.tratamiento[i].codigo <> '' then
              begin
              gotoxy(21,12 + j);
              writeln (x3.tratamiento[i].codigo);
              gotoxy(32,12 + j);
              writeln (x3.tratamiento[i].descripcion);
              j := j+2;
              end
          else
              bandera := true;
          i := i + 1;
     end;

     gotoxy(21,11);
     write ('———————');
     gotoxy(29,11);
     write ('————————————————————————————————————————————————————————————————————————');
     gotoxy(21,13);
     write ('———————');
     gotoxy(29,13);
     write ('————————————————————————————————————————————————————————————————————————');
     gotoxy(21,15);
     write ('———————');
     gotoxy(29,15);
     write ('————————————————————————————————————————————————————————————————————————');
     gotoxy(21,17);
     write ('———————');
     gotoxy(29,17);
     write ('————————————————————————————————————————————————————————————————————————');
     gotoxy(21,19);
     write ('———————');
     gotoxy(29,19);
     write ('————————————————————————————————————————————————————————————————————————');
     gotoxy(21,21);
     write ('———————');
     gotoxy(29,21);
     write ('————————————————————————————————————————————————————————————————————————');
     gotoxy(21,23);
     write ('———————');
     gotoxy(29,23);
     write ('————————————————————————————————————————————————————————————————————————');
     gotoxy(21,25);
     write ('———————');
     gotoxy(29,25);
     write ('————————————————————————————————————————————————————————————————————————');

     gotoxy(28,10);
     write ('|');
     gotoxy(28,11);
     write ('|');
     gotoxy(28,12);
     write ('|');
     gotoxy(28,13);
     write ('|');
     gotoxy(28,14);
     write ('|');
     gotoxy(28,15);
     write ('|');
     gotoxy(28,16);
     write ('|');
     gotoxy(28,17);
     write ('|');
     gotoxy(28,18);
     write ('|');
     gotoxy(28,19);
     write ('|');
     gotoxy(28,20);
     write ('|');
     gotoxy(28,21);
     write ('|');
     gotoxy(28,22);
     write ('|');
     gotoxy(28,23);
     write ('|');
     gotoxy(28,24);
     write ('|');
     gotoxy(28,25);
     write ('|');
     gotoxy(28,26);
     write ('|');

     gotoxy(21,27);
     write ('————————————————————————————————————————————————————————————————————————————————');

     gotoxy(101,4);
     write ('|');
     gotoxy(101,5);
     write ('|');
     gotoxy(101,6);
     write ('|');
     gotoxy(101,7);
     write ('|');
     gotoxy(101,8);
     write ('|');
     gotoxy(101,9);
     write ('|');
     gotoxy(101,10);
     write ('|');
     gotoxy(101,11);
     write ('|');
     gotoxy(101,12);
     write ('|');
     gotoxy(101,13);
     write ('|');
     gotoxy(101,14);
     write ('|');
     gotoxy(101,15);
     write ('|');
     gotoxy(101,16);
     write ('|');
     gotoxy(101,17);
     write ('|');
     gotoxy(101,18);
     write ('|');
     gotoxy(101,19);
     write ('|');
     gotoxy(101,20);
     write ('|');
     gotoxy(101,21);
     write ('|');
     gotoxy(101,22);
     write ('|');
     gotoxy(101,23);
     write ('|');
     gotoxy(101,24);
     write ('|');
     gotoxy(101,25);
     write ('|');
     gotoxy(101,26);
     write ('|');

     readkey;
     end;

end.

