program project1;
 
{$codepage UTF8}

uses CRT;

VAR
  opcion:byte;

begin
 repeat
 clrscr;
 writeln ('1- ABMC de Personas');
 writeln ('2- ');
 writeln ('3- ');
 writeln ('0- Salir');
 writeln ('Seleccione opción: ');
 readln (opcion);
 case opcion of
 1: ABMC_Personas();
 2:
 end;
 until opcion = 0;
END.


