Unit U_vectores;

INTERFACE

{$codepage UTF8}

 USES
 crt;

 CONST
 n = 12;

 TYPE
 T_dato_vec = record
   cant_atenciones: word;
   mes:string[15];
 end;

 T_vector = array [1..n] of T_dato_vec;

 procedure inicializar (var vec:T_vector);

IMPLEMENTATION

 procedure inicializar (var vec:T_vector);
 var
 i: 1..n;
 begin
 for i:= 1 to n do
 begin
      vec[i].cant_atenciones:= 0;
      vec[i].mes := '';
 end;
 end;

 {procedure guardar(var vec:T_vector);
 var
 i: 1..n;
 begin
 clrscr;
 for i:=1 to n do
 begin
      gotoxy (40,10);
      write ('Ingrese valor: ');
      readln (vec[i]);
 end;
 end;}

 END.
